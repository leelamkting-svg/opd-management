// shared.jsx — shared icons + small UI primitives. Exposes to window.

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ---------- Icons (24px stroke=1.5) ---------------------------------
const I = ({ d, fill, size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill || "none"}
       stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
    {typeof d === "string" ? <path d={d} /> : d}
  </svg>
);
const Icon = {
  Home: (p) => <I {...p} d="M3 11.5L12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z" />,
  Calendar: (p) => <I {...p} d={<><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 9h18M8 3v4M16 3v4"/></>} />,
  Users: (p) => <I {...p} d={<><circle cx="9" cy="9" r="3.5"/><path d="M2 20c.6-3.4 3.5-5 7-5s6.4 1.6 7 5"/><circle cx="17" cy="8" r="2.5"/><path d="M16 14c2.8 0 5 1.4 6 4"/></>} />,
  UserPlus: (p) => <I {...p} d={<><circle cx="10" cy="8" r="3.5"/><path d="M3 20c.6-3.4 3.2-5 7-5 2 0 3.6.5 5 1.5"/><path d="M18 14v6M15 17h6"/></>} />,
  Stethoscope: (p) => <I {...p} d={<><path d="M5 3v6a4 4 0 0 0 8 0V3"/><path d="M9 13v3a4 4 0 0 0 4 4 4 4 0 0 0 4-4v-2"/><circle cx="17" cy="11" r="2.2"/></>} />,
  Pill: (p) => <I {...p} d={<><rect x="3" y="9" width="18" height="6" rx="3" transform="rotate(-30 12 12)"/><path d="M9 7l6 10"/></>} />,
  Pencil: (p) => <I {...p} d="M4 20l1-4 11-11a2.1 2.1 0 0 1 3 3L8 19l-4 1z" />,
  Brush: (p) => <I {...p} d={<><path d="M14 4l6 6-6 6-4-4"/><path d="M10 12L3 19a2 2 0 0 0 3 3l7-7"/></>} />,
  Mic: (p) => <I {...p} d={<><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></>} />,
  MessageCircle: (p) => <I {...p} d="M21 11.5a8.4 8.4 0 0 1-9 8.5 8.4 8.4 0 0 1-4-1L3 21l1-5a8.4 8.4 0 0 1 9-13 8.4 8.4 0 0 1 8 8.5z" />,
  Phone: (p) => <I {...p} d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3.1-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .3 2 .6 3a2 2 0 0 1-.4 2.1L8 10.1a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c1 .3 2 .5 3 .6a2 2 0 0 1 1.7 2z" />,
  Search: (p) => <I {...p} d={<><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></>} />,
  Bell: (p) => <I {...p} d={<><path d="M6 9a6 6 0 0 1 12 0c0 7 3 7 3 9H3c0-2 3-2 3-9z"/><path d="M10 21a2 2 0 0 0 4 0"/></>} />,
  Plus: (p) => <I {...p} d="M12 5v14M5 12h14" />,
  Check: (p) => <I {...p} d="M5 12l5 5L20 7" />,
  X: (p) => <I {...p} d="M6 6l12 12M18 6L6 18" />,
  Arrow: (p) => <I {...p} d="M5 12h14M13 5l7 7-7 7" />,
  Up: (p) => <I {...p} d="M5 15l7-7 7 7" />,
  Down: (p) => <I {...p} d="M5 9l7 7 7-7" />,
  Right: (p) => <I {...p} d="M9 5l7 7-7 7" />,
  Doc: (p) => <I {...p} d={<><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h6"/></>} />,
  Folder: (p) => <I {...p} d="M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />,
  Receipt: (p) => <I {...p} d={<><path d="M4 3v18l2-1.5L8 21l2-1.5L12 21l2-1.5L16 21l2-1.5L20 21V3z"/><path d="M8 8h8M8 12h8M8 16h5"/></>} />,
  QR: (p) => <I {...p} d={<><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3M20 14v7M14 20h3"/></>} />,
  Bank: (p) => <I {...p} d={<><path d="M3 10l9-6 9 6"/><path d="M5 10v8M9 10v8M15 10v8M19 10v8"/><path d="M3 21h18"/></>} />,
  Link: (p) => <I {...p} d={<><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7L11 7"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7L13 17"/></>} />,
  Sparkles: (p) => <I {...p} d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8" />,
  Hospital: (p) => <I {...p} d={<><path d="M3 21V9l9-6 9 6v12"/><path d="M9 21v-6h6v6M12 8v4M10 10h4"/></>} />,
  Heart: (p) => <I {...p} d="M12 21s-7-4.5-9.4-9A5 5 0 0 1 12 6a5 5 0 0 1 9.4 6c-2.4 4.5-9.4 9-9.4 9z" />,
  Settings: (p) => <I {...p} d={<><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></>} />,
  Trash: (p) => <I {...p} d={<><path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13"/></>} />,
  Upload: (p) => <I {...p} d="M12 16V4M6 10l6-6 6 6M4 20h16" />,
  Wallet: (p) => <I {...p} d={<><rect x="3" y="6" width="18" height="14" rx="2"/><path d="M16 13h3"/></>} />,
  Eye: (p) => <I {...p} d={<><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></>} />,
  Clock: (p) => <I {...p} d={<><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>} />,
  Send: (p) => <I {...p} d="M22 2L11 13M22 2l-7 20-4-9-9-4z" />,
  Undo: (p) => <I {...p} d="M9 14L4 9l5-5M4 9h10a6 6 0 1 1 0 12h-3" />,
  Redo: (p) => <I {...p} d="M15 14l5-5-5-5M20 9H10a6 6 0 1 0 0 12h3" />,
  Image: (p) => <I {...p} d={<><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="9" r="1.5"/><path d="M21 16l-5-5-9 9"/></>} />,
  Activity: (p) => <I {...p} d="M22 12h-4l-3 8-6-16-3 8H2" />,
  Filter: (p) => <I {...p} d="M3 4h18l-7 9v6l-4-2v-4z" />,
  Eraser: (p) => <I {...p} d={<><path d="M14 4l7 7-9 9H6l-3-3z"/><path d="M11 7l7 7"/></>} />,
  Save: (p) => <I {...p} d={<><path d="M5 3h11l4 4v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M7 3v6h9V3M7 21v-7h10v7"/></>} />,
};

// ---------- Small components ----------------------------------------
function Badge({ kind = "default", children, dot }) {
  return <span className={`badge ${kind === "default" ? "" : kind}`}>
    {dot ? <span className="dot" /> : null}{children}
  </span>;
}

function Avatar({ name, size }) {
  const initials = (name || "").split(/\s+/).map(w => w[0]).slice(0, 2).join("").toUpperCase();
  const cls = "avatar" + (size === "sm" ? " sm" : size === "lg" ? " lg" : "");
  // Deterministic-ish color
  const palette = ["#1F4D44","#B87A3A","#2C594F","#8E5A23","#3D6E63","#6B4218"];
  const bg = palette[(name?.charCodeAt(0) ?? 0) % palette.length] + "22";
  const fg = palette[(name?.charCodeAt(0) ?? 0) % palette.length];
  return <span className={cls} style={{ background: bg, color: fg }}>{initials}</span>;
}

function Modal({ open, onClose, title, subtitle, children, footer, width }) {
  useEffect(() => {
    if (!open) return;
    const k = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="scrim" onClick={(e) => { if (e.target.classList.contains("scrim")) onClose(); }}>
      <div className="modal" style={width ? { maxWidth: width } : {}} onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <div>
            <h2>{title}</h2>
            {subtitle ? <p>{subtitle}</p> : null}
          </div>
          <button className="icon-btn" onClick={onClose}><Icon.X size={16} /></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer ? <div className="modal-foot">{footer}</div> : null}
      </div>
    </div>
  );
}

function Stat({ label, value, unit, delta, icon, accent }) {
  return (
    <div className="stat" style={accent ? { borderTop: `3px solid ${accent}` } : {}}>
      <div className="lbl">{label}</div>
      <div className="val">{unit ? <span className="unit">{unit}</span> : null}{value}</div>
      {delta != null ? (
        <div className={"delta" + (delta < 0 ? " down" : "")}>
          {delta < 0 ? "↓" : "↑"} {Math.abs(delta)} vs last week
        </div>
      ) : null}
      <div className="glyph">{icon}</div>
    </div>
  );
}

function inr(n) {
  if (n == null) return "—";
  return "₹" + n.toLocaleString("en-IN");
}

function formatTime(t) { return t; }
function relTime(iso) {
  const d = new Date(iso);
  const diff = (Date.now() - d.getTime()) / 1000;
  if (diff < 60) return "just now";
  if (diff < 3600) return Math.floor(diff/60) + "m ago";
  if (diff < 86400) return Math.floor(diff/3600) + "h ago";
  return Math.floor(diff/86400) + "d ago";
}

// Doctor lookup
function doctorById(id) {
  return (window.KAAYANTAR_DATA.doctors.find(d => d.id === id)) || { name: "—", spec: "" };
}

// ---------- Toast --------------------------------------------------
const ToastCtx = React.createContext({ push: () => {} });
function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((t) => {
    const id = Math.random().toString(36).slice(2);
    setToasts(ts => [...ts, { id, ...t }]);
    setTimeout(() => setToasts(ts => ts.filter(x => x.id !== id)), t.duration || 4000);
  }, []);
  return (
    <ToastCtx.Provider value={{ push }}>
      {children}
      <div style={{
        position: "fixed", right: 18, bottom: 18, zIndex: 1000,
        display: "flex", flexDirection: "column", gap: 8, maxWidth: 340,
      }}>
        {toasts.map(t => (
          <div key={t.id} style={{
            background: "var(--bg-elev)", border: "1px solid var(--line-strong)",
            borderRadius: 12, padding: "12px 14px", boxShadow: "var(--sh-2)",
            display: "flex", gap: 10, alignItems: "flex-start",
            animation: "rise .2s ease-out",
          }}>
            <div style={{
              width: 28, height: 28, borderRadius: 8,
              background: t.kind === "wa" ? "#DCF8C6" : "var(--emerald-50)",
              color: t.kind === "wa" ? "#075E54" : "var(--emerald-700)",
              display: "grid", placeItems: "center", flexShrink: 0,
            }}>
              {t.kind === "wa" ? <Icon.MessageCircle size={16} /> : <Icon.Check size={16} />}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 500 }}>{t.title}</div>
              {t.body ? <div style={{ fontSize: 12, color: "var(--text-mute)", marginTop: 2 }}>{t.body}</div> : null}
            </div>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
const useToast = () => React.useContext(ToastCtx);

Object.assign(window, {
  Icon, Badge, Avatar, Modal, Stat,
  inr, formatTime, relTime, doctorById,
  ToastProvider, useToast,
});
