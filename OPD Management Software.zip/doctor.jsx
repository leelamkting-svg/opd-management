// doctor.jsx — Doctor portal: queue + consult workspace (prescription, drawing, voice, education)
const DR = {};

DR.Queue = function ({ go }) {
  const D = window.KAAYANTAR_DATA;
  const doc = D.doctors[0];
  return (
    <div>
      <div className="canvas-head">
        <div>
          <h1>Today's clinic, {doc.name.split(" ")[1]}</h1>
          <p>{doc.spec} · 6 patients today · 2 surgeries this week</p>
        </div>
        <div className="actions">
          <button className="btn"><Icon.Calendar size={14} /> Block time</button>
          <button className="btn primary" onClick={() => go({ view: "consult", id: "p-001" })}>
            <Icon.Stethoscope size={14} /> Start consult
          </button>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        <Stat label="Up next"           value="11:00" delta={null} icon={<Icon.Clock size={70} />} accent="#1F4D44" />
        <Stat label="Avg consult"       value="14" unit="min" delta={-1} icon={<Icon.Activity size={70} />} accent="#3D6E63" />
        <Stat label="Rx written"        value="124" delta={+8} icon={<Icon.Pill size={70} />} accent="#B87A3A" />
        <Stat label="Surgeries planned" value="4" delta={+1} icon={<Icon.Heart size={70} />} accent="#8E5A23" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 14 }}>
        <div className="card">
          <div className="card-title">
            <h3>Patient queue</h3>
            <span style={{ fontSize: 11, color: "var(--text-mute)" }}>Click to start consult</span>
          </div>
          <table className="tbl">
            <thead><tr><th>Time</th><th>Patient</th><th>Type</th><th>Reason</th><th>Prep</th><th></th></tr></thead>
            <tbody>
              {D.todaysAppts.filter(a => a.doctor === "dr-ps").map(a => {
                const p = D.patients.find(x => x.id === a.pid);
                return (
                  <tr key={a.pid}>
                    <td style={{ fontFamily: "var(--f-mono)", fontWeight: 500 }}>{a.time}</td>
                    <td>
                      <div className="pt-cell">
                        <Avatar name={a.name} size="sm" />
                        <div>
                          <div className="name">{a.name}</div>
                          <div className="meta">{p.age}y · {p.sex}</div>
                        </div>
                      </div>
                    </td>
                    <td>{a.type === "new" ? <Badge kind="accent">New</Badge> : <Badge kind="brand">Follow #{p.visit.count}</Badge>}</td>
                    <td style={{ fontSize: 12.5, color: "var(--text-mute)" }}>
                      {p.surgery.suggested ? p.surgery.procedure : (p.history[0]?.note?.slice(0, 40) + "…")}
                    </td>
                    <td>
                      {p.docs.reports + p.docs.photos > 0
                        ? <Badge kind="ok" dot>Files attached</Badge>
                        : <Badge kind="warn">No reports</Badge>}
                    </td>
                    <td style={{ textAlign: "right" }}>
                      <button className="btn sm primary" onClick={() => go({ view: "consult", id: a.pid })}>
                        Open <Icon.Right size={12} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="card">
            <div className="card-title"><h3>This week — OT board</h3></div>
            {[
              { d: "Mon 18", l: "Liposuction — A. Mehta", c: "#1F4D44" },
              { d: "Thu 21", l: "Rhinoplasty — D. Shah", c: "#B87A3A" },
              { d: "Wed 27", l: "RYGB — V. Singh",       c: "#8E5A23" },
              { d: "Sat 30", l: "Mommy makeover — TBD",  c: "#3D6E63" },
            ].map((s, i) => (
              <div key={i} style={{
                display: "flex", alignItems: "center", gap: 10, padding: "8px 0",
                borderBottom: i < 3 ? "1px dashed var(--line)" : "0",
              }}>
                <div style={{ width: 8, height: 8, borderRadius: 4, background: s.c }} />
                <div style={{ flex: 1, fontSize: 12.5 }}>
                  <b>{s.d}</b> — <span style={{ color: "var(--text-mute)" }}>{s.l}</span>
                </div>
                <button className="btn sm ghost"><Icon.Right size={12} /></button>
              </div>
            ))}
          </div>
          <div className="card" style={{
            background: "linear-gradient(135deg, var(--emerald-50), var(--cream-200))",
          }}>
            <div className="card-title">
              <h3 style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <Icon.Sparkles size={14} /> AI scribe
              </h3>
            </div>
            <div style={{ fontSize: 12, color: "var(--text-mute)", lineHeight: 1.5 }}>
              When you start the consult, the room mic transcribes your conversation. The patient receives the recording on WhatsApp so they can revisit what was explained — and your prescription, anatomy sketches, and education links get attached too.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// Consult Workspace — the heart of the doctor portal
// ============================================================
DR.Consult = function ({ id, go }) {
  const D = window.KAAYANTAR_DATA;
  const p = D.patients.find(x => x.id === id) || D.patients[0];
  const [tool, setTool] = useState("rx");
  const toast = useToast();

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: "var(--text-mute)", marginBottom: 10 }}>
        <button className="btn sm ghost" onClick={() => go({ view: "queue" })}>← Queue</button>
        <span>/</span><span>Consult</span><span>/</span><span>{p.name}</span>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "280px 1fr", gap: 14, height: "calc(100vh - 180px)", minHeight: 580 }}>
        <ConsultSidebar p={p} tool={tool} setTool={setTool} />
        <div className="card" style={{ padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
          {tool === "rx"     && <PrescriptionTool p={p} />}
          {tool === "draw"   && <DrawingBoard     p={p} />}
          {tool === "voice"  && <VoiceNotes       p={p} />}
          {tool === "edu"    && <EducationLibrary p={p} />}
          {tool === "nextop" && <NextOpdScheduler p={p} go={go} />}
        </div>
      </div>
    </div>
  );
};

function ConsultSidebar({ p, tool, setTool }) {
  const doc = doctorById(p.visit.doctor);
  return (
    <div className="card" style={{ display: "flex", flexDirection: "column", padding: 16, gap: 14 }}>
      <div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Avatar name={p.name} />
          <div>
            <div style={{ fontFamily: "var(--f-display)", fontSize: 18, fontWeight: 500 }}>{p.name}</div>
            <div style={{ fontSize: 11.5, color: "var(--text-mute)" }}>
              {p.age}y · {p.sex} · {p.tags[0] || "—"}
            </div>
          </div>
        </div>
        <div style={{ fontSize: 11.5, color: "var(--text-mute)", marginTop: 8, fontFamily: "var(--f-mono)" }}>
          {p.phone}
        </div>
      </div>

      <div className="divider" style={{ margin: 0 }} />

      <div>
        <div style={{ fontSize: 10.5, color: "var(--text-mute)", textTransform: "uppercase",
                      letterSpacing: ".08em", fontWeight: 600, marginBottom: 6 }}>Today</div>
        <div style={{ fontSize: 12.5, lineHeight: 1.7 }}>
          <div>{p.visit.type === "new" ? "New OPD" : `Follow-up #${p.visit.count}`}</div>
          <div style={{ color: "var(--text-mute)" }}>{p.visit.date} · {p.visit.time}</div>
        </div>
      </div>

      <div>
        <div style={{ fontSize: 10.5, color: "var(--text-mute)", textTransform: "uppercase",
                      letterSpacing: ".08em", fontWeight: 600, marginBottom: 6 }}>Past notes</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 4, fontSize: 12 }}>
          {p.history.slice(0, 3).map((h, i) => (
            <div key={i} style={{ padding: "6px 8px", background: "var(--bg-sunken)", borderRadius: 6 }}>
              <div style={{ fontFamily: "var(--f-mono)", fontSize: 10.5, color: "var(--text-mute)" }}>{h.date}</div>
              <div>{h.note}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ marginTop: "auto" }}>
        <div style={{ fontSize: 10.5, color: "var(--text-mute)", textTransform: "uppercase",
                      letterSpacing: ".08em", fontWeight: 600, marginBottom: 6 }}>Consult tools</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <ToolBtn id="rx"     icon={<Icon.Pill size={14} />}       label="Prescription"  active={tool} onClick={setTool} />
          <ToolBtn id="draw"   icon={<Icon.Brush size={14} />}      label="Drawing board" active={tool} onClick={setTool} />
          <ToolBtn id="voice"  icon={<Icon.Mic size={14} />}        label="Voice notes"   active={tool} onClick={setTool} />
          <ToolBtn id="edu"    icon={<Icon.MessageCircle size={14} />} label="Share education" active={tool} onClick={setTool} />
          <ToolBtn id="nextop" icon={<Icon.Calendar size={14} />}   label="Next OPD"      active={tool} onClick={setTool} />
        </div>
      </div>
    </div>
  );
}

function ToolBtn({ id, icon, label, active, onClick }) {
  const on = active === id;
  return (
    <button onClick={() => onClick(id)} style={{
      display: "flex", alignItems: "center", gap: 8,
      padding: "8px 10px", borderRadius: 8,
      border: "1px solid " + (on ? "var(--brand)" : "transparent"),
      background: on ? "var(--emerald-50)" : "transparent",
      color: on ? "var(--emerald-700)" : "var(--text)",
      fontSize: 12.5, fontWeight: 500, width: "100%", textAlign: "left",
    }}>
      <span style={{
        width: 22, height: 22, borderRadius: 6,
        background: on ? "var(--emerald-700)" : "var(--bg-sunken)",
        color: on ? "#fff" : "var(--text-mute)",
        display: "grid", placeItems: "center", flexShrink: 0,
      }}>{icon}</span>
      {label}
    </button>
  );
}

// ============================================================
// Prescription Tool — handwriting OCR via Claude
// ============================================================
function PrescriptionTool({ p }) {
  const D = window.KAAYANTAR_DATA;
  const toast = useToast();
  const [items, setItems] = useState([
    { drug: "Tab. Pantoprazole 40 mg", dose: "1-0-0", dur: "5 days", notes: "Before breakfast" },
    { drug: "Tab. Ultracet",           dose: "1-0-1", dur: "3 days", notes: "After food, SOS pain" },
  ]);
  const [hwImage, setHwImage] = useState(null);
  const [ocring, setOcring] = useState(false);
  const [hwError, setHwError] = useState("");
  const fileInputRef = useRef();

  const addRow = () => setItems(i => [...i, { drug: "", dose: "", dur: "", notes: "" }]);
  const updateRow = (i, k, v) => setItems(items.map((it, idx) => idx === i ? { ...it, [k]: v } : it));
  const removeRow = (i) => setItems(items.filter((_, idx) => idx !== i));

  // Simulated handwriting upload: accepts any file → Claude API to transcribe pasted text
  const handleHandwritingUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setHwImage(file.name);
    setOcring(true);
    setHwError("");
    try {
      // Demo-only — ask Claude to invent a plausible Rx OCR for a plastic-surgery follow-up
      const text = await window.claude.complete({
        messages: [{
          role: "user",
          content: `You are a handwriting OCR module. The image filename is "${file.name}".
A plastic surgeon at Kaayantar Clinic has written a prescription for a follow-up patient
named ${p.name}, age ${p.age}, who is on day-${p.surgery?.done ? 22 : 5} post-op for ${p.surgery?.procedure || "post-bariatric body contouring"}.
Output ONLY a JSON array of 3-5 line items, each with keys "drug","dose","dur","notes".
Use realistic Indian-context brand names. Do not include any other text.`
        }]
      });
      const match = text.match(/\[[\s\S]*\]/);
      if (!match) throw new Error("Couldn't parse OCR output");
      const parsed = JSON.parse(match[0]);
      setItems(parsed);
      toast.push({ title: "Handwriting transcribed", body: `${parsed.length} medicines extracted` });
    } catch (err) {
      setHwError("Couldn't read this handwriting clearly. Try a sharper photo.");
    } finally {
      setOcring(false);
    }
  };

  return (
    <>
      <ConsultHead title="Prescription" subtitle="Type fast · paste handwriting · or upload a photo">
        <input ref={fileInputRef} type="file" accept="image/*" style={{ display: "none" }} onChange={handleHandwritingUpload} />
        <button className="btn sm" onClick={() => fileInputRef.current?.click()}>
          <Icon.Upload size={12} /> Handwriting → Rx
        </button>
        <button className="btn sm"><Icon.Save size={12} /> Save draft</button>
        <button className="btn sm primary"
          onClick={() => toast.push({ kind: "wa", title: "Prescription sent", body: `${p.name} · ${p.phone}` })}>
          <Icon.MessageCircle size={12} /> Send on WhatsApp
        </button>
      </ConsultHead>

      <div style={{ flex: 1, padding: 18, overflow: "auto", display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 14 }}>
        <div>
          {ocring && (
            <div style={{
              padding: 12, borderRadius: 10,
              background: "var(--info-bg)", color: "var(--info-fg)",
              marginBottom: 10, display: "flex", alignItems: "center", gap: 10, fontSize: 12.5,
            }}>
              <Icon.Sparkles size={14} />
              <span className="pulse">Reading "{hwImage}" · transcribing handwriting via Kaayantar AI…</span>
            </div>
          )}
          {hwError && (
            <div style={{
              padding: 12, borderRadius: 10,
              background: "var(--err-bg)", color: "var(--err-fg)",
              marginBottom: 10, fontSize: 12.5,
            }}>{hwError}</div>
          )}

          <div style={{ overflow: "auto", border: "1px solid var(--line)", borderRadius: 10 }}>
            <table className="tbl" style={{ fontSize: 12.5 }}>
              <thead>
                <tr>
                  <th style={{ width: "42%" }}>Drug</th>
                  <th>Dosage</th>
                  <th>Duration</th>
                  <th>Notes</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {items.map((it, i) => (
                  <tr key={i}>
                    <td><RxInput value={it.drug} onChange={(v) => updateRow(i, "drug", v)} suggest={D.rxFavourites.map(f => f.drug)} placeholder="e.g. Tab. Augmentin 625" /></td>
                    <td><input className="input" style={{ fontFamily: "var(--f-mono)" }} value={it.dose} onChange={(e) => updateRow(i, "dose", e.target.value)} placeholder="1-0-1" /></td>
                    <td><input className="input" value={it.dur} onChange={(e) => updateRow(i, "dur", e.target.value)} placeholder="5 days" /></td>
                    <td><input className="input" value={it.notes} onChange={(e) => updateRow(i, "notes", e.target.value)} placeholder="After food" /></td>
                    <td><button className="btn sm ghost" onClick={() => removeRow(i)}><Icon.Trash size={12} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
            <button className="btn sm" onClick={addRow}><Icon.Plus size={12} /> Add medicine</button>
            {D.rxFavourites.slice(0, 4).map((f, i) => (
              <button key={i} className="chip" onClick={() => setItems(its => [...its, f])}>+ {f.drug}</button>
            ))}
          </div>
        </div>

        <RxPreview p={p} items={items} />
      </div>
    </>
  );
}

function RxInput({ value, onChange, suggest = [], placeholder }) {
  const [focus, setFocus] = useState(false);
  const matches = value
    ? suggest.filter(s => s.toLowerCase().includes(value.toLowerCase())).slice(0, 4)
    : [];
  return (
    <div style={{ position: "relative" }}>
      <input className="input" value={value} placeholder={placeholder}
             onChange={(e) => onChange(e.target.value)}
             onFocus={() => setFocus(true)}
             onBlur={() => setTimeout(() => setFocus(false), 150)} />
      {focus && matches.length > 0 && (
        <div style={{
          position: "absolute", top: "100%", left: 0, right: 0, zIndex: 10,
          background: "var(--bg-elev)", border: "1px solid var(--line-strong)",
          borderRadius: 8, marginTop: 2, boxShadow: "var(--sh-2)",
        }}>
          {matches.map((m, i) => (
            <div key={i} onClick={() => onChange(m)} style={{ padding: "6px 10px", fontSize: 12, cursor: "default" }}
                 onMouseEnter={(e) => e.currentTarget.style.background = "var(--bg-sunken)"}
                 onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}>
              {m}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function RxPreview({ p, items }) {
  return (
    <div className="rx-sheet">
      <div className="watermark">Kaayantar</div>
      <div style={{ fontFamily: "var(--f-display)", fontSize: 18, fontWeight: 500, color: "var(--emerald-700)", lineHeight: 1.1 }}>
        Kaayantar Clinic
      </div>
      <div style={{ fontSize: 10.5, color: "var(--text-mute)", marginBottom: 12 }}>
        Sindhu Bhavan Road · Ahmedabad · 380054 · +91 79 4000 0000
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, marginBottom: 12, borderTop: "1px solid var(--line)", borderBottom: "1px solid var(--line)", padding: "6px 0" }}>
        <span><b>{p.name}</b> · {p.age}{p.sex}</span>
        <span>UHID K-{p.id.slice(-3).toUpperCase()}</span>
        <span>{p.visit.date}</span>
      </div>
      <div style={{ fontFamily: "var(--f-display)", fontSize: 28, color: "var(--bronze-500)", lineHeight: 1, marginBottom: 6 }}>℞</div>
      <div className="rx-grid" style={{ minHeight: 200, paddingTop: 4 }}>
        {items.map((it, i) => (
          <div key={i} style={{ height: 22, lineHeight: "22px", fontSize: 11.5, display: "flex" }}>
            <span style={{ width: 24, color: "var(--text-mute)" }}>{i + 1}.</span>
            <span style={{ flex: 1 }}>
              <b style={{ fontWeight: 600 }}>{it.drug || <i style={{ color: "var(--text-dim)" }}>—</i>}</b>
              {it.drug ? <> &nbsp;·&nbsp; <span>{it.dose}</span> &nbsp;·&nbsp; <span>{it.dur}</span></> : null}
            </span>
            {it.notes && <span style={{ color: "var(--text-mute)" }}>{it.notes}</span>}
          </div>
        ))}
      </div>
      <div style={{ marginTop: 14, fontSize: 11, color: "var(--text-mute)" }}>
        <div>Advice: Review in 7 days · Avoid NSAIDs · Diet — high-protein 60g/day</div>
        <div style={{ marginTop: 18, textAlign: "right" }}>
          <div style={{ fontFamily: "var(--f-display)", fontSize: 16, color: "var(--emerald-700)", fontStyle: "italic" }}>Dr. P.S.</div>
          <div style={{ fontSize: 10 }}>MS, MCh (Plastic) · MCI 56432</div>
        </div>
      </div>
    </div>
  );
}

function ConsultHead({ title, subtitle, children }) {
  return (
    <div style={{
      padding: "14px 18px", borderBottom: "1px solid var(--line)",
      display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10,
      background: "var(--bg-sunken)",
    }}>
      <div>
        <div style={{ fontFamily: "var(--f-display)", fontSize: 20, fontWeight: 500, letterSpacing: "-.005em" }}>{title}</div>
        {subtitle && <div style={{ fontSize: 11.5, color: "var(--text-mute)" }}>{subtitle}</div>}
      </div>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "flex-end" }}>{children}</div>
    </div>
  );
}

// ============================================================
// Drawing Board — anatomy templates + freehand
// ============================================================
function DrawingBoard({ p }) {
  const [template, setTemplate] = useState(
    p.surgery.procedure?.includes("Sleeve") ? "sleeve"
    : p.surgery.procedure?.includes("Bypass") ? "rygb"
    : p.surgery.procedure?.includes("Rhinoplasty") ? "nose"
    : p.surgery.procedure?.includes("Liposuction") || p.surgery.procedure?.includes("Body Contouring") ? "abdomen"
    : "blank"
  );
  const [tool, setTool] = useState("pen");
  const [color, setColor] = useState("#B87A3A");
  const [thickness, setThickness] = useState(3);
  const [strokes, setStrokes] = useState([]);
  const [redoStack, setRedoStack] = useState([]);
  const [current, setCurrent] = useState(null);
  const svgRef = useRef();
  const toast = useToast();

  const colors = ["#B87A3A", "#1F4D44", "#8B2F22", "#0E1513", "#4285F4"];
  const D = window.KAAYANTAR_DATA;

  const getPoint = (e) => {
    const rect = svgRef.current.getBoundingClientRect();
    const x = ((e.clientX || e.touches?.[0]?.clientX) - rect.left) / rect.width * 400;
    const y = ((e.clientY || e.touches?.[0]?.clientY) - rect.top) / rect.height * 500;
    return { x, y };
  };

  const onDown = (e) => {
    e.preventDefault();
    const pt = getPoint(e);
    setCurrent({ tool, color: tool === "eraser" ? "transparent" : color, w: thickness, pts: [pt] });
    setRedoStack([]);
  };
  const onMove = (e) => {
    if (!current) return;
    e.preventDefault();
    const pt = getPoint(e);
    setCurrent(c => ({ ...c, pts: [...c.pts, pt] }));
  };
  const onUp = () => {
    if (current && current.pts.length > 1) setStrokes(s => [...s, current]);
    setCurrent(null);
  };

  const undo = () => {
    if (!strokes.length) return;
    setRedoStack(r => [...r, strokes[strokes.length - 1]]);
    setStrokes(s => s.slice(0, -1));
  };
  const redo = () => {
    if (!redoStack.length) return;
    setStrokes(s => [...s, redoStack[redoStack.length - 1]]);
    setRedoStack(r => r.slice(0, -1));
  };
  const clear = () => { setStrokes([]); setRedoStack([]); };

  const pathFromStroke = (pts) => {
    if (pts.length < 2) return "";
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 1; i < pts.length; i++) {
      d += ` L ${pts[i].x} ${pts[i].y}`;
    }
    return d;
  };

  const Template = Anatomy[template];

  return (
    <>
      <ConsultHead title="Drawing board" subtitle="Annotate anatomy & explain — auto-saves to patient record">
        <button className="btn sm"
          onClick={() => toast.push({ kind: "wa", title: "Drawing shared", body: `${p.name} · saved to record + WhatsApp` })}>
          <Icon.MessageCircle size={12} /> Send to patient
        </button>
        <button className="btn sm primary"
          onClick={() => toast.push({ title: "Saved to record", body: "Today's drawing pinned to OPD note" })}>
          <Icon.Save size={12} /> Save to record
        </button>
      </ConsultHead>

      <div style={{ display: "grid", gridTemplateColumns: "240px 1fr", gap: 0, flex: 1, minHeight: 0 }}>
        <div style={{ borderRight: "1px solid var(--line)", padding: 14, overflow: "auto" }}>
          <div style={{ fontSize: 10.5, color: "var(--text-mute)", textTransform: "uppercase", letterSpacing: ".08em", fontWeight: 600, marginBottom: 8 }}>
            Plastic surgery
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 14 }}>
            {D.anatomyTemplates.filter(t => t.group === "plastic").map(t => (
              <TemplateChip key={t.id} t={t} active={template === t.id} onClick={() => setTemplate(t.id)} />
            ))}
          </div>
          <div style={{ fontSize: 10.5, color: "var(--text-mute)", textTransform: "uppercase", letterSpacing: ".08em", fontWeight: 600, marginBottom: 8 }}>
            Bariatric
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 14 }}>
            {D.anatomyTemplates.filter(t => t.group === "bariatric").map(t => (
              <TemplateChip key={t.id} t={t} active={template === t.id} onClick={() => setTemplate(t.id)} />
            ))}
          </div>
          <div style={{ fontSize: 10.5, color: "var(--text-mute)", textTransform: "uppercase", letterSpacing: ".08em", fontWeight: 600, marginBottom: 8 }}>
            General
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
            {D.anatomyTemplates.filter(t => t.group === "general").map(t => (
              <TemplateChip key={t.id} t={t} active={template === t.id} onClick={() => setTemplate(t.id)} />
            ))}
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
          <div style={{ padding: 8, borderBottom: "1px solid var(--line)", display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap", background: "var(--bg-sunken)" }}>
            <div className="draw-tool">
              <button className={tool === "pen" ? "on" : ""}    onClick={() => setTool("pen")}     title="Pen"><Icon.Pencil size={14} /></button>
              <button className={tool === "eraser" ? "on" : ""} onClick={() => setTool("eraser")} title="Eraser"><Icon.Eraser size={14} /></button>
              <div className="sep" />
              <button onClick={undo} title="Undo"><Icon.Undo size={14} /></button>
              <button onClick={redo} title="Redo"><Icon.Redo size={14} /></button>
              <div className="sep" />
              <button onClick={clear} title="Clear all"><Icon.Trash size={14} /></button>
            </div>
            <div className="draw-tool">
              {colors.map(c => (
                <button key={c} onClick={() => { setColor(c); setTool("pen"); }} title={c}>
                  <span className={"color-pick" + (color === c ? " on" : "")} style={{ background: c }} />
                </button>
              ))}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: "var(--text-mute)" }}>
              <span>Stroke</span>
              <input type="range" min="1" max="10" value={thickness} onChange={(e) => setThickness(+e.target.value)} style={{ width: 80 }} />
              <span style={{ fontFamily: "var(--f-mono)", width: 18 }}>{thickness}</span>
            </div>
            <div style={{ marginLeft: "auto", fontSize: 11, color: "var(--text-mute)" }}>
              Template: <b style={{ color: "var(--text)" }}>{D.anatomyTemplates.find(t => t.id === template)?.name}</b>
            </div>
          </div>

          <div style={{ flex: 1, padding: 18, background: "var(--bg-sunken)", display: "grid", placeItems: "center", overflow: "auto" }}>
            <div style={{
              background: "#FCFAF5", borderRadius: 14, boxShadow: "var(--sh-2)",
              border: "1px solid var(--line)",
              width: "min(560px, 100%)", aspectRatio: "4/5", position: "relative",
            }}>
              <svg ref={svgRef} viewBox="0 0 400 500" width="100%" height="100%"
                   onMouseDown={onDown} onMouseMove={onMove} onMouseUp={onUp} onMouseLeave={onUp}
                   onTouchStart={onDown} onTouchMove={onMove} onTouchEnd={onUp}
                   style={{ cursor: tool === "eraser" ? "cell" : "crosshair", touchAction: "none", display: "block", color: "#3a3a3a" }}>
                {Template && <Template />}
                {strokes.map((s, i) => (
                  <path key={i} d={pathFromStroke(s.pts)} stroke={s.tool === "eraser" ? "#FCFAF5" : s.color} strokeWidth={s.w}
                        fill="none" strokeLinecap="round" strokeLinejoin="round" />
                ))}
                {current && (
                  <path d={pathFromStroke(current.pts)} stroke={current.tool === "eraser" ? "#FCFAF5" : current.color} strokeWidth={current.w}
                        fill="none" strokeLinecap="round" strokeLinejoin="round" />
                )}
              </svg>
              {strokes.length === 0 && (
                <div style={{
                  position: "absolute", bottom: 12, left: 14, fontSize: 11,
                  color: "var(--text-dim)", fontFamily: "var(--f-mono)",
                }}>Click and drag to draw · {template === "blank" ? "or pick a template ←" : "annotated " + (template) + " template loaded"}</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function TemplateChip({ t, active, onClick }) {
  return (
    <button onClick={onClick} style={{
      border: "1px solid " + (active ? "var(--brand)" : "var(--line)"),
      background: active ? "var(--emerald-50)" : "var(--bg-elev)",
      color: active ? "var(--emerald-700)" : "var(--text)",
      borderRadius: 8, padding: "6px 8px",
      fontSize: 11, fontWeight: 500, textAlign: "left",
      display: "flex", alignItems: "center", gap: 6,
    }}>
      <span style={{
        width: 22, height: 28, borderRadius: 4,
        background: "var(--bg-sunken)",
        display: "grid", placeItems: "center",
        color: active ? "var(--emerald-700)" : "var(--text-mute)",
      }}>
        <svg viewBox="0 0 400 500" width="18" height="22">
          {Anatomy[t.id === "bodyF" ? "bodyF" : t.id]
            ? React.createElement(Anatomy[t.id === "body-f" ? "bodyF" : t.id === "body-m" ? "bodyM" : t.id] || (() => null))
            : null}
        </svg>
      </span>
      {t.name}
    </button>
  );
}

// ============================================================
// Voice notes — live transcription via Claude
// ============================================================
function VoiceNotes({ p }) {
  const [recording, setRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [transcript, setTranscript] = useState(
    "Patient on day-22 post sleeve gastrectomy. Tolerating soft diet, reports occasional reflux at night. " +
    "On examination, ports healing well, no induration. Advised to continue Pantoprazole, " +
    "add walking 30 min twice a day. Discussed body-contouring options for 12-month review."
  );
  const [summary, setSummary] = useState("");
  const [loadingSum, setLoadingSum] = useState(false);
  const [textInput, setTextInput] = useState("");
  const toast = useToast();

  useEffect(() => {
    if (!recording) return;
    const t = setInterval(() => setDuration(d => d + 1), 1000);
    return () => clearInterval(t);
  }, [recording]);

  const summarize = async () => {
    setLoadingSum(true);
    try {
      const out = await window.claude.complete({
        messages: [{
          role: "user",
          content: `Summarize this doctor-patient conversation in 3 sections for the patient to revisit on WhatsApp.
Use simple language a patient can understand. Output exactly this structure:
**What we discussed today:** (1-2 sentences)
**What you need to do:** (3-4 bullet points)
**Watch out for:** (1-2 bullet points)

Conversation:
${transcript}`
        }]
      });
      setSummary(out);
      toast.push({ kind: "wa", title: "Summary ready", body: "Patient-friendly version generated" });
    } catch (err) {
      setSummary("Couldn't generate summary right now. Please try again.");
    } finally {
      setLoadingSum(false);
    }
  };

  const fmtDur = (s) => `${String(Math.floor(s/60)).padStart(2, "0")}:${String(s%60).padStart(2, "0")}`;

  return (
    <>
      <ConsultHead title="Voice notes" subtitle="Auto-transcribed · summarised for patient · stored as audio note">
        <button className="btn sm" onClick={summarize} disabled={loadingSum || !transcript}>
          <Icon.Sparkles size={12} /> {loadingSum ? "Summarising…" : "Summarise for patient"}
        </button>
        <button className="btn sm primary"
                onClick={() => toast.push({ kind: "wa", title: "Audio + summary sent", body: `${p.name} can replay anytime` })}>
          <Icon.MessageCircle size={12} /> Send to patient
        </button>
      </ConsultHead>

      <div style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 1fr", overflow: "hidden" }}>
        <div style={{ padding: 18, overflow: "auto", borderRight: "1px solid var(--line)", display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button onClick={() => setRecording(!recording)} style={{
              width: 56, height: 56, borderRadius: "50%", border: 0,
              background: recording ? "#E04A3A" : "var(--brand)",
              color: "#fff", display: "grid", placeItems: "center",
              boxShadow: recording ? "0 0 0 6px rgba(224, 74, 58, .18)" : "var(--sh-2)",
              transition: "all .2s",
            }}>
              {recording ? <div style={{ width: 16, height: 16, background: "#fff", borderRadius: 3 }} /> : <Icon.Mic size={22} />}
            </button>
            <div>
              <div style={{ fontFamily: "var(--f-display)", fontSize: 22, fontWeight: 500, fontFeatureSettings: "tnum" }}>
                {fmtDur(duration)}
              </div>
              <div style={{ fontSize: 12, color: recording ? "#E04A3A" : "var(--text-mute)", display: "flex", alignItems: "center", gap: 6 }}>
                {recording ? <><span className="pulse" style={{ width: 8, height: 8, borderRadius: 4, background: "#E04A3A", display: "inline-block" }} /> Recording · live transcription</> : "Tap to start recording"}
              </div>
            </div>
            <div style={{ marginLeft: "auto", display: "flex", gap: 4, alignItems: "flex-end", height: 36 }}>
              {[6, 14, 22, 12, 28, 18, 24, 10, 20, 14, 26, 8].map((h, i) => (
                <div key={i} style={{
                  width: 3, background: recording ? "var(--brand)" : "var(--line-strong)",
                  height: recording ? h + Math.sin((Date.now() + i * 200) / 200) * 6 : 3,
                  borderRadius: 2,
                  animation: recording ? `wave 1s ${i * 0.08}s infinite alternate` : "none",
                }} />
              ))}
            </div>
          </div>

          <div className="divider" style={{ margin: 0 }} />

          <div>
            <div style={{ fontSize: 10.5, color: "var(--text-mute)", textTransform: "uppercase", letterSpacing: ".08em", fontWeight: 600, marginBottom: 6 }}>
              Live transcript
            </div>
            <textarea className="textarea" rows="10" value={transcript} onChange={(e) => setTranscript(e.target.value)}
                      placeholder="Conversation will appear here as you speak…" />
            <div className="helper" style={{ marginTop: 6 }}>
              <Icon.Sparkles size={12} /> Multi-speaker · supports Hindi-English code switching · medical vocabulary tuned for plastic & bariatric surgery
            </div>
          </div>

          <div className="divider" style={{ margin: 0 }} />

          <div>
            <div style={{ fontSize: 10.5, color: "var(--text-mute)", textTransform: "uppercase", letterSpacing: ".08em", fontWeight: 600, marginBottom: 6 }}>
              Or type a quick note
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              <input className="input" value={textInput} onChange={(e) => setTextInput(e.target.value)} placeholder="Type then press add…" />
              <button className="btn sm" onClick={() => { if (textInput.trim()) { setTranscript(t => t + " " + textInput); setTextInput(""); } }}>Add</button>
            </div>
          </div>
        </div>

        <div style={{ padding: 18, overflow: "auto", display: "flex", flexDirection: "column", gap: 12, background: "var(--bg-sunken)" }}>
          <div style={{ fontSize: 10.5, color: "var(--text-mute)", textTransform: "uppercase", letterSpacing: ".08em", fontWeight: 600 }}>
            Patient-friendly summary
          </div>
          {loadingSum ? (
            <div style={{ padding: 14, background: "var(--bg-elev)", borderRadius: 10, color: "var(--text-mute)", fontSize: 12.5 }}>
              <span className="pulse">Composing easy-to-read version for {p.name}…</span>
            </div>
          ) : summary ? (
            <div style={{ padding: 14, background: "var(--bg-elev)", borderRadius: 10, fontSize: 12.5, lineHeight: 1.65, whiteSpace: "pre-wrap" }}>
              {summary.split(/(\*\*[^*]+\*\*)/g).map((part, i) =>
                part.startsWith("**") ? <b key={i}>{part.slice(2, -2)}</b> : <span key={i}>{part}</span>
              )}
            </div>
          ) : (
            <div className="empty" style={{ padding: 18 }}>
              <div style={{ fontSize: 13, marginBottom: 4, fontWeight: 500 }}>No summary yet</div>
              <div className="helper">Click "Summarise for patient" — Kaayantar AI will translate medical language into a friendly recap.</div>
            </div>
          )}
        </div>
      </div>
      <style>{`
        @keyframes wave { from { height: 4px; } to { height: 28px; } }
      `}</style>
    </>
  );
}

// ============================================================
// Education library — send disease videos / IG links
// ============================================================
function EducationLibrary({ p }) {
  const D = window.KAAYANTAR_DATA;
  const [picked, setPicked] = useState(new Set(["ig-1", "yt-1"]));
  const toast = useToast();
  const toggle = (id) => setPicked(s => {
    const n = new Set(s);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  });
  const platformColor = (p) => ({
    Instagram: "#E1306C", YouTube: "#CD201F", PDF: "#B05A30",
  }[p] || "#1F4D44");
  return (
    <>
      <ConsultHead title="Share education" subtitle="Tick what's relevant — patient gets a single WhatsApp with all the links">
        <button className="btn sm" onClick={() => setPicked(new Set())}>Clear</button>
        <button className="btn sm primary"
                onClick={() => toast.push({ kind: "wa", title: `${picked.size} link${picked.size > 1 ? "s" : ""} sent`, body: `${p.name} · combined into one message` })}>
          <Icon.MessageCircle size={12} /> Send {picked.size} item{picked.size > 1 ? "s" : ""}
        </button>
      </ConsultHead>
      <div style={{ padding: 18, overflow: "auto", flex: 1, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, alignContent: "flex-start" }}>
        {D.educationLibrary.map(item => {
          const on = picked.has(item.id);
          const c = platformColor(item.platform);
          return (
            <div key={item.id} onClick={() => toggle(item.id)} style={{
              border: "1.5px solid " + (on ? "var(--brand)" : "var(--line)"),
              background: on ? "var(--emerald-50)" : "var(--bg-elev)",
              borderRadius: 12, padding: 14,
              display: "flex", gap: 12, alignItems: "flex-start",
              cursor: "default",
            }}>
              <div style={{
                width: 44, height: 44, borderRadius: 9,
                background: c + "18", color: c,
                display: "grid", placeItems: "center", flexShrink: 0,
              }}>
                <Icon.MessageCircle size={20} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <Badge>{item.platform}</Badge>
                </div>
                <div style={{ fontSize: 13, fontWeight: 500, marginTop: 6, lineHeight: 1.35 }}>{item.title}</div>
                <div style={{ fontFamily: "var(--f-mono)", fontSize: 10.5, color: "var(--text-mute)", marginTop: 4 }}>{item.url}</div>
              </div>
              <div style={{
                width: 22, height: 22, borderRadius: 6,
                background: on ? "var(--emerald-700)" : "transparent",
                border: "1.5px solid " + (on ? "var(--emerald-700)" : "var(--line-strong)"),
                display: "grid", placeItems: "center", color: "#fff", flexShrink: 0,
              }}>{on ? <Icon.Check size={14} /> : null}</div>
            </div>
          );
        })}
      </div>
    </>
  );
}

// ============================================================
// Next OPD — schedule next visit, sync GCal
// ============================================================
function NextOpdScheduler({ p, go }) {
  const D = window.KAAYANTAR_DATA;
  const [days, setDays] = useState(p.surgery.suggested && !p.surgery.done ? 3 : 14);
  const [autoBook, setAutoBook] = useState(true);
  const toast = useToast();
  const nextDate = new Date(2026, 4, 16 + days);

  return (
    <>
      <ConsultHead title="Next OPD" subtitle="Auto-book + Google Calendar sync (no OT overlap)">
        <button className="btn sm primary"
                onClick={() => toast.push({ kind: "wa", title: "Follow-up booked", body: `${nextDate.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" })} · WhatsApp sent` })}>
          <Icon.Check size={12} /> Confirm & send WhatsApp
        </button>
      </ConsultHead>
      <div style={{ flex: 1, padding: 22, overflow: "auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <div>
          <div className="field">
            <label>Follow up in</label>
            <div style={{ display: "flex", gap: 4, flexWrap: "wrap", marginBottom: 8 }}>
              {[3, 7, 14, 21, 30, 60].map(d => (
                <button key={d} className={"chip" + (days === d ? " active" : "")} onClick={() => setDays(d)}>
                  {d} day{d > 1 ? "s" : ""}
                </button>
              ))}
            </div>
            <input className="input" type="number" value={days} onChange={(e) => setDays(+e.target.value)} />
            <div className="helper">
              Suggested: <b>{
                p.surgery.suggested && !p.surgery.done ? "3 days — pre-op review" :
                p.surgery.done && p.surgery.procedure.includes("Sleeve") ? "7 days — post-op suture review" :
                "14 days — routine follow-up"
              }</b>
            </div>
          </div>

          <div style={{
            marginTop: 18, padding: 14, border: "1px solid var(--line)", borderRadius: 10,
            background: "var(--bg-sunken)",
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
              <div>
                <div style={{ fontSize: 12, color: "var(--text-mute)" }}>Next OPD</div>
                <div style={{ fontFamily: "var(--f-display)", fontSize: 22, fontWeight: 500 }}>
                  {nextDate.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" })}
                </div>
                <div style={{ fontFamily: "var(--f-mono)", fontSize: 13, color: "var(--text-mute)" }}>11:30</div>
              </div>
              <Badge kind="ok" dot>Slot available</Badge>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderTop: "1px dashed var(--line)" }}>
              <input type="checkbox" checked={autoBook} onChange={(e) => setAutoBook(e.target.checked)} />
              <div style={{ fontSize: 12.5 }}>
                <div style={{ fontWeight: 500 }}>Auto-book this slot</div>
                <div style={{ color: "var(--text-mute)", fontSize: 11 }}>Patient & doctor both get WhatsApp confirmation</div>
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0", borderTop: "1px dashed var(--line)" }}>
              <div style={{ width: 18, height: 18, borderRadius: 4, background: "#4285F4", color: "#fff", display: "grid", placeItems: "center", fontSize: 10, fontWeight: 600 }}>G</div>
              <div style={{ fontSize: 12.5 }}>
                <div style={{ fontWeight: 500 }}>Google Calendar — synced</div>
                <div style={{ color: "var(--text-mute)", fontSize: 11 }}>Checked against OT bookings, no overlap</div>
              </div>
              <Badge kind="ok" style={{ marginLeft: "auto" }}>Clear</Badge>
            </div>
          </div>
        </div>

        <div>
          <div style={{ fontSize: 10.5, color: "var(--text-mute)", textTransform: "uppercase", letterSpacing: ".08em", fontWeight: 600, marginBottom: 8 }}>
            Conflict check — {doctorById(p.visit.doctor).name}
          </div>
          <div style={{ background: "var(--bg-sunken)", borderRadius: 12, padding: 14, height: 340, overflow: "hidden" }}>
            <DayCalendarForDate />
          </div>
        </div>
      </div>
    </>
  );
}

function DayCalendarForDate() {
  // re-use DayCalendar visually (uses the function defined in frontdesk.jsx — accessible via global since both share window scope after Babel)
  const hours = []; for (let h = 9; h <= 18; h++) hours.push(h);
  const rowH = 30;
  const events = [
    { t: "09:00", dur: 60, l: "OT — Rhinoplasty",  c: "#6B4218" },
    { t: "11:30", dur: 30, l: "Follow-up · ★ NEW", c: "#B87A3A" },
    { t: "12:00", dur: 30, l: "OPD — confirmed",    c: "#1F4D44" },
    { t: "14:00", dur: 30, l: "Photoshoot",         c: "#4A5552" },
    { t: "16:00", dur: 60, l: "OT — Liposuction",   c: "#8E5A23" },
  ];
  return (
    <div style={{ position: "relative", height: hours.length * rowH }}>
      {hours.map(h => (
        <div key={h} style={{
          display: "flex", gap: 8, borderTop: "1px dashed var(--line-strong)",
          height: rowH, alignItems: "flex-start",
        }}>
          <div style={{ width: 40, fontFamily: "var(--f-mono)", fontSize: 10.5, color: "var(--text-mute)", paddingTop: 3 }}>
            {String(h).padStart(2, "0")}:00
          </div>
          <div style={{ flex: 1 }} />
        </div>
      ))}
      {events.map((e, i) => {
        const [h, m] = e.t.split(":").map(Number);
        const top = (h - 9) * rowH + (m / 60) * rowH;
        const height = (e.dur / 60) * rowH;
        return (
          <div key={i} style={{
            position: "absolute", left: 48, right: 0, top, height: height - 2,
            background: e.c, color: "#fff", borderRadius: 6, padding: "3px 8px",
            fontSize: 10.5, fontWeight: 500, display: "flex", alignItems: "center",
          }}>{e.t} · {e.l}</div>
        );
      })}
    </div>
  );
}

Object.assign(window, { DR });
