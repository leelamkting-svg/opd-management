// data.js — sample data for Kaayantar OPD prototype

window.KAAYANTAR_DATA = (() => {
  const today = new Date(2026, 4, 16); // May 16, 2026
  const fmt = (d) => d.toISOString().slice(0, 10);

  const doctors = [
    { id: "dr-ps",  name: "Dr. P.S.",            spec: "Aesthetic & Plastic Surgery",  fee: 1500, color: "#1F4D44" },
    { id: "dr-apk", name: "Dr. Aman Priya K.",   spec: "Bariatric & General Surgery",  fee: 1500, color: "#B87A3A" },
    { id: "dr-nv",  name: "Dr. Neha V.",          spec: "Dermatology / Non-surgical",   fee: 1000, color: "#8E5A23" },
  ];

  const hospitals = [
    { id: "ko",  name: "Kaayantar OT, Sindhu Bhavan Rd", kind: "In-house clinic OT",    addr: "Sindhu Bhavan Rd, Ahmedabad" },
    { id: "ap",  name: "Apollo Hospital, Gandhinagar",    kind: "Tertiary care",         addr: "Gandhinagar" },
    { id: "ho",  name: "HCG Hospital, Mithakhali",         kind: "Surgical centre",       addr: "Mithakhali, Ahmedabad" },
    { id: "kd",  name: "KD Hospital, Vaishnodevi",         kind: "Tertiary care",         addr: "Vaishnodevi Circle" },
  ];

  const leadSources = [
    "Instagram Ad",
    "Instagram Organic",
    "Google Search",
    "Practo",
    "Doctor Referral",
    "Word of Mouth",
    "Walk-in",
    "YouTube",
  ];

  const procedures = [
    "Rhinoplasty",
    "HD Liposuction",
    "Tummy Tuck / Abdominoplasty",
    "Mommy Makeover",
    "Gynecomastia Surgery",
    "Breast Augmentation",
    "Sleeve Gastrectomy",
    "Gastric Bypass (RYGB)",
    "Post-Bariatric Body Contouring",
    "Buccal Fat Removal",
    "Six-Pack Creation",
    "Hair PRP",
    "Botox / Fillers",
  ];

  const patients = [
    {
      id: "p-001",
      name: "Aanya Mehta",
      age: 34, dob: "1992-03-14", sex: "F", phone: "+91 98250 12340",
      city: "Ahmedabad",
      lead: { source: "Instagram Ad", createdAt: "2026-04-21T11:20:00", firstOpdAt: "2026-05-08T11:00:00" },
      visit: { type: "follow-up", count: 3, doctor: "dr-ps", date: "2026-05-16", time: "11:00", fee: 1500 },
      status: "surgery-planned",
      tags: ["VIP", "Insurance"],
      surgery: {
        suggested: true,
        procedure: "Post-Bariatric Body Contouring",
        hospital: "ko",
        date: "2026-06-04", time: "08:30",
        packageInr: 285000,
        insurance: "Star Health — TPA approval pending",
        preopFile: "preop-bodycontour-v3.pdf",
      },
      docs: { id: 2, reports: 5, photos: 4, consents: 1 },
      emergency: { name: "Ravi Mehta (Husband)", phone: "+91 98240 90909" },
      history: [
        { date: "2026-05-08", note: "Initial consult — discussed lower body lift after 38 kg weight loss." },
        { date: "2026-04-30", note: "Pre-bariatric labs reviewed; cleared by physician." },
        { date: "2026-04-21", note: "Lead from Instagram, scheduled OPD." },
      ],
    },
    {
      id: "p-002",
      name: "Rohan Patel",
      age: 28, dob: "1997-11-02", sex: "M", phone: "+91 99098 22210",
      city: "Surat",
      lead: { source: "Google Search", createdAt: "2026-05-10T09:00:00", firstOpdAt: "2026-05-16T11:30:00" },
      visit: { type: "new", count: 1, doctor: "dr-ps", date: "2026-05-16", time: "11:30", fee: 1500 },
      status: "checked-in",
      tags: ["New"],
      surgery: { suggested: false },
      docs: { id: 1, reports: 0, photos: 0, consents: 0 },
      emergency: { name: "Pratik Patel (Brother)", phone: "+91 99098 11122" },
      history: [
        { date: "2026-05-10", note: "Lead via Google — gynecomastia query." },
      ],
    },
    {
      id: "p-003",
      name: "Meera Joshi",
      age: 41, dob: "1985-07-08", sex: "F", phone: "+91 96875 44120",
      city: "Ahmedabad",
      lead: { source: "Doctor Referral", createdAt: "2026-02-12T15:00:00", firstOpdAt: "2026-02-19T10:00:00" },
      visit: { type: "follow-up", count: 4, doctor: "dr-apk", date: "2026-05-16", time: "12:00", fee: 1500 },
      status: "post-op-day-22",
      tags: ["Post-op", "Bariatric"],
      surgery: {
        suggested: true,
        procedure: "Sleeve Gastrectomy",
        hospital: "ap", done: true,
        date: "2026-04-24", time: "07:00",
        packageInr: 425000,
        insurance: "Self-pay",
        preopFile: "preop-sleeve-v2.pdf",
      },
      docs: { id: 2, reports: 14, photos: 6, consents: 3 },
      emergency: { name: "Kiran Joshi (Husband)", phone: "+91 96780 23400" },
      history: [
        { date: "2026-04-24", note: "Sleeve gastrectomy completed — Apollo. Discharge D+3." },
        { date: "2026-04-10", note: "Pre-op labs, dietician counselling." },
      ],
    },
    {
      id: "p-004",
      name: "Imran Sheikh",
      age: 36, dob: "1990-01-22", sex: "M", phone: "+91 97278 56012",
      city: "Vadodara",
      lead: { source: "Practo", createdAt: "2026-05-13T18:30:00", firstOpdAt: "2026-05-16T12:30:00" },
      visit: { type: "new", count: 1, doctor: "dr-ps", date: "2026-05-16", time: "12:30", fee: 1500 },
      status: "waiting",
      tags: ["New"],
      surgery: { suggested: false },
      docs: { id: 0, reports: 0, photos: 0, consents: 0 },
      emergency: { name: "Nazima Sheikh (Mother)", phone: "+91 97278 23456" },
      history: [
        { date: "2026-05-13", note: "Practo enquiry — facial rejuvenation." },
      ],
    },
    {
      id: "p-005",
      name: "Diya Shah",
      age: 23, dob: "2002-09-30", sex: "F", phone: "+91 98989 67120",
      city: "Ahmedabad",
      lead: { source: "Instagram Organic", createdAt: "2026-05-01T20:00:00", firstOpdAt: "2026-05-09T15:00:00" },
      visit: { type: "follow-up", count: 2, doctor: "dr-ps", date: "2026-05-16", time: "13:00", fee: 1500 },
      status: "estimate-shared",
      tags: ["Estimate"],
      surgery: {
        suggested: true,
        procedure: "Rhinoplasty",
        hospital: "ho",
        date: "2026-06-12", time: "09:00",
        packageInr: 210000,
        insurance: "Self-pay",
        preopFile: "preop-rhino-v1.pdf",
      },
      docs: { id: 2, reports: 2, photos: 8, consents: 0 },
      emergency: { name: "Anjali Shah (Mother)", phone: "+91 98989 33344" },
      history: [
        { date: "2026-05-09", note: "Initial consult — rhinoplasty planning, profile photos taken." },
        { date: "2026-05-01", note: "DM enquiry from @kaayantarindia post." },
      ],
    },
    {
      id: "p-006",
      name: "Vikram Singh",
      age: 52, dob: "1973-12-12", sex: "M", phone: "+91 90909 11233",
      city: "Jaipur",
      lead: { source: "YouTube", createdAt: "2026-04-05T22:10:00", firstOpdAt: "2026-04-12T11:00:00" },
      visit: { type: "follow-up", count: 2, doctor: "dr-apk", date: "2026-05-16", time: "14:30", fee: 1500 },
      status: "pre-op-prep",
      tags: ["Out-of-state", "Bariatric"],
      surgery: {
        suggested: true,
        procedure: "Gastric Bypass (RYGB)",
        hospital: "kd",
        date: "2026-05-28", time: "07:30",
        packageInr: 510000,
        insurance: "Niva Bupa — pre-auth approved",
        preopFile: "preop-rygb-v4.pdf",
      },
      docs: { id: 3, reports: 11, photos: 2, consents: 2 },
      emergency: { name: "Pooja Singh (Wife)", phone: "+91 90909 88812" },
      history: [
        { date: "2026-05-02", note: "Anaesthesia clearance, cardio echo done." },
        { date: "2026-04-12", note: "First consult — BMI 41, T2D, comorbidities reviewed." },
      ],
    },
  ];

  // Schedule (today's calendar)
  const todaysAppts = patients.map(p => ({
    pid: p.id, name: p.name, time: p.visit.time, doctor: p.visit.doctor,
    type: p.visit.type, status: p.status, tags: p.tags,
  })).sort((a, b) => a.time.localeCompare(b.time));

  // Time slots for booking grid
  const slots = [];
  for (let h = 10; h <= 18; h++) {
    for (let m = 0; m < 60; m += 30) {
      const t = `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
      slots.push(t);
    }
  }
  // mark busy
  const busy = new Set(["10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "14:30", "15:00", "16:00", "17:00"]);

  // Funnel data for CRM
  const funnelDistribution = [
    { label: "Lead",           value: 412 },
    { label: "OPD Booked",     value: 286 },
    { label: "OPD Done",       value: 241 },
    { label: "Surgery Sugg.",  value: 134 },
    { label: "IPD Booked",     value: 72  },
    { label: "Completed",      value: 64  },
  ];

  // Average lead → OPD, OPD → IPD times
  const crmStats = {
    leadToOpd: { days: 4.2, delta: -0.6 },
    opdToIpd:  { days: 18.4, delta: +1.2 },
    leadCount: 412,
    leadConv:  0.156,
  };

  // Pre-loaded anatomy templates for drawing board
  // Each one is a small SVG drawing the user can annotate over
  const anatomyTemplates = [
    { id: "blank",   name: "Clean slate",       group: "general" },
    { id: "face",    name: "Face — frontal",    group: "plastic" },
    { id: "nose",    name: "Nose — profile",     group: "plastic" },
    { id: "abdomen", name: "Abdomen — Lipo zones", group: "plastic" },
    { id: "breast",  name: "Breast — markings",   group: "plastic" },
    { id: "body-f",  name: "Body — Female",       group: "plastic" },
    { id: "body-m",  name: "Body — Male",         group: "plastic" },
    { id: "sleeve",  name: "Sleeve Gastrectomy",   group: "bariatric" },
    { id: "rygb",    name: "Gastric Bypass (RYGB)", group: "bariatric" },
    { id: "bmi",     name: "BMI / Comorbidity Map", group: "bariatric" },
  ];

  // Common Rx items (autocomplete simulation)
  const rxFavourites = [
    { drug: "Tab. Pantoprazole 40 mg",      dose: "1-0-0",     dur: "5 days",  notes: "Before breakfast" },
    { drug: "Tab. Ultracet",                dose: "1-0-1",     dur: "3 days",  notes: "After food, SOS pain" },
    { drug: "Cap. Augmentin 625",            dose: "1-1-1",     dur: "5 days",  notes: "Complete course" },
    { drug: "Syp. Looz 15 ml",               dose: "0-0-1",     dur: "7 days",  notes: "Bedtime" },
    { drug: "Tab. Multivitamin B-complex",    dose: "1-0-0",     dur: "30 days", notes: "Post-bariatric protocol" },
    { drug: "Inj. Clexane 40 mg s/c",         dose: "0-1-0",     dur: "7 days",  notes: "DVT prophylaxis" },
  ];

  const educationLibrary = [
    { id: "ig-1", platform: "Instagram", title: "How to prepare for liposuction — Dr. P.S.",        url: "instagram.com/p/Cx1Lipo" },
    { id: "yt-1", platform: "YouTube",   title: "What to expect after Sleeve Gastrectomy (12 min)", url: "youtu.be/kaay-sleeve" },
    { id: "ig-2", platform: "Instagram", title: "Rhinoplasty — Recovery Day-by-Day reel",            url: "instagram.com/p/Cx2Rhino" },
    { id: "pdf-1", platform: "PDF",      title: "Bariatric diet — Phase 1 to 4 (Marathi/Hindi)",     url: "kaayantar.com/files/diet.pdf" },
    { id: "yt-2", platform: "YouTube",   title: "Tummy Tuck FAQ — addressing 12 common doubts",       url: "youtu.be/kaay-tt" },
    { id: "ig-3", platform: "Instagram", title: "Pre-op skincare for facial procedures",              url: "instagram.com/p/Cx3Skin" },
  ];

  return {
    today, doctors, hospitals, leadSources, procedures,
    patients, todaysAppts, slots, busy,
    funnelDistribution, crmStats,
    anatomyTemplates, rxFavourites, educationLibrary,
  };
})();
