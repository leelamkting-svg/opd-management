// app.jsx — Main app shell: rail, sidebar, topbar, router, CRM strip, tweaks panel

const { useState, useEffect, useRef } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "role": "frontdesk",
  "showCRM": true,
  "dark": false
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [route, setRoute] = useState({ view: "dashboard" });
  const [bookingOpen, setBookingOpen] = useState(false);

  // Theme
  useEffect(() => {
    document.documentElement.dataset.theme = t.dark ? "dark" : "light";
  }, [t.dark]);

  // When role changes, send to that role's home
  useEffect(() => {
    if (t.role === "frontdesk") setRoute({ view: "dashboard" });
    else if (t.role === "doctor") setRoute({ view: "queue" });
    else if (t.role === "admin") setRoute({ view: "admin" });
  }, [t.role]);

  const go = (r) => setRoute(r);

  const appClass = "app" +
    (t.showCRM ? " crm-open" : "");

  // Selected patient ID for CRM strip context
  const patientForCRM =
    route.view === "patient" || route.view === "consult" ? route.id : null;

  return (
    <ToastProvider>
      <div className={appClass}>
        <Rail role={t.role} setTweak={setTweak} go={go} route={route} />
        <Topbar role={t.role} setTweak={setTweak} go={go} route={route} />
        <Sidebar role={t.role} go={go} route={route} openBooking={() => setBookingOpen(true)} />
        <main className="canvas" data-screen-label={`${t.role} · ${route.view}`}>
          {t.role === "frontdesk" && route.view === "dashboard"   && <FD.Dashboard   go={go} openBooking={() => setBookingOpen(true)} />}
          {t.role === "frontdesk" && route.view === "patients"     && <FD.PatientList go={go} openBooking={() => setBookingOpen(true)} />}
          {t.role === "doctor"    && route.view === "queue"        && <DR.Queue      go={go} />}
          {t.role === "doctor"    && route.view === "consult"      && <DR.Consult    id={route.id} go={go} />}
          {t.role === "admin"     && route.view === "admin"        && <Admin.Dashboard go={go} />}
          {(route.view === "patient")                                && <PatientProfile id={route.id} go={go} />}
          {/* Placeholder views for any nav not built fully */}
          {(route.view === "calendar" || route.view === "messages" || route.view === "billing" || route.view === "settings") && (
            <PlaceholderView view={route.view} />
          )}
        </main>
        {t.showCRM && (
          <aside className="crm">
            <CRMStrip patientId={patientForCRM} role={t.role} />
          </aside>
        )}

        {/* Booking modal */}
        <FD.BookingModal open={bookingOpen} onClose={() => setBookingOpen(false)} />

        <TweaksPanel>
          <TweakSection label="Role" />
          <TweakRadio
            label="View as"
            value={t.role}
            options={["frontdesk", "doctor", "admin"]}
            onChange={(v) => setTweak("role", v)} />
          <TweakSection label="Layout" />
          <TweakToggle
            label="CRM panel"
            value={t.showCRM}
            onChange={(v) => setTweak("showCRM", v)} />
          <TweakToggle
            label="Dark mode"
            value={t.dark}
            onChange={(v) => setTweak("dark", v)} />
        </TweaksPanel>
      </div>
    </ToastProvider>
  );
}

// ============================================================
// Rail (icon column)
// ============================================================
function Rail({ role, setTweak, go, route }) {
  const items = role === "frontdesk" ? [
    { id: "dashboard", icon: <Icon.Home size={18} />,    label: "Home" },
    { id: "patients",  icon: <Icon.Users size={18} />,   label: "Patients" },
    { id: "calendar",  icon: <Icon.Calendar size={18} />, label: "Calendar" },
    { id: "billing",   icon: <Icon.Wallet size={18} />,  label: "Billing" },
    { id: "messages",  icon: <Icon.MessageCircle size={18} />, label: "Messages" },
  ] : role === "doctor" ? [
    { id: "queue",     icon: <Icon.Stethoscope size={18} />, label: "Queue" },
    { id: "patients",  icon: <Icon.Users size={18} />,       label: "Patients" },
    { id: "calendar",  icon: <Icon.Calendar size={18} />,    label: "OT board" },
    { id: "messages",  icon: <Icon.MessageCircle size={18} />, label: "Messages" },
  ] : [
    { id: "admin",     icon: <Icon.Activity size={18} />,    label: "Overview" },
    { id: "patients",  icon: <Icon.Users size={18} />,       label: "Patients" },
    { id: "billing",   icon: <Icon.Wallet size={18} />,      label: "Revenue" },
    { id: "settings",  icon: <Icon.Settings size={18} />,    label: "Settings" },
  ];
  return (
    <div className="rail">
      <div className="rail-logo" title="Kaayantar">K</div>
      {items.map(it => {
        const on = route.view === it.id;
        return (
          <button key={it.id} className={"rail-btn" + (on ? " on" : "")} title={it.label}
                  onClick={() => go({ view: it.id })}>
            {it.icon}
          </button>
        );
      })}
      <div className="rail-spacer" />
      <button className="rail-btn" title="Settings"><Icon.Settings size={18} /></button>
    </div>
  );
}

// ============================================================
// Topbar
// ============================================================
function Topbar({ role, setTweak, go, route }) {
  const D = window.KAAYANTAR_DATA;
  const userByRole = {
    frontdesk: { n: "Asmita Patel",  r: "Front Desk · Sindhu Bhavan Rd", init: "AP" },
    doctor:    { n: "Dr. P. Shah",    r: "Aesthetic & Plastic Surgery", init: "PS" },
    admin:     { n: "Kaayantar Admin", r: "Clinic Operations",      init: "KA" },
  };
  const u = userByRole[role];

  const here =
    route.view === "dashboard"  ? "Dashboard" :
    route.view === "patients"   ? "Patients" :
    route.view === "patient"    ? "Patient profile" :
    route.view === "queue"      ? "Patient queue" :
    route.view === "consult"    ? "Consult room" :
    route.view === "admin"      ? "Operations overview" :
    route.view === "calendar"   ? "Calendar" :
    route.view === "messages"   ? "Messages" :
    route.view === "billing"    ? "Billing" :
    route.view === "settings"   ? "Settings" : route.view;

  return (
    <header className="topbar">
      <div className="brand">Kaayantar <span>OPD</span></div>
      <div className="crumbs">
        <span>{role === "frontdesk" ? "Front Desk" : role === "doctor" ? "Doctor" : "Admin"}</span>
        <span>›</span>
        <span className="here">{here}</span>
      </div>

      <div className="search">
        <Icon.Search size={14} />
        <input placeholder="Search patients, UHID, phone…" />
        <span className="kbd">⌘K</span>
      </div>

      <div className="role-switch">
        <button className={role === "frontdesk" ? "active" : ""} onClick={() => setTweak("role", "frontdesk")}>Front Desk</button>
        <button className={role === "doctor" ? "active" : ""}    onClick={() => setTweak("role", "doctor")}>Doctor</button>
        <button className={role === "admin" ? "active" : ""}     onClick={() => setTweak("role", "admin")}>Admin</button>
      </div>

      <button className="icon-btn" title="Notifications">
        <Icon.Bell size={16} />
        <span className="dot" />
      </button>

      <div className="who">
        <div className="avatar">{u.init}</div>
        <div className="who-meta">
          <b>{u.n}</b>
          <span>{u.r}</span>
        </div>
      </div>
    </header>
  );
}

// ============================================================
// Sidebar
// ============================================================
function Sidebar({ role, go, route, openBooking }) {
  const D = window.KAAYANTAR_DATA;
  const groups = role === "frontdesk" ? [
    {
      h: "Today", items: [
        { id: "dashboard", icon: <Icon.Home size={14} />,     l: "Overview",        b: "6" },
        { id: "queue",     icon: <Icon.Clock size={14} />,    l: "Live queue",      b: "3" },
        { id: "calendar",  icon: <Icon.Calendar size={14} />, l: "Calendar" },
      ],
    },
    {
      h: "Records", items: [
        { id: "patients",  icon: <Icon.Users size={14} />,   l: "All patients",   b: D.patients.length + "" },
        { id: "messages",  icon: <Icon.MessageCircle size={14} />, l: "WhatsApp" },
        { id: "billing",   icon: <Icon.Wallet size={14} />,  l: "Billing" },
      ],
    },
  ] : role === "doctor" ? [
    {
      h: "Clinic", items: [
        { id: "queue",     icon: <Icon.Stethoscope size={14} />, l: "Today's queue", b: "6" },
        { id: "patients",  icon: <Icon.Users size={14} />,       l: "My patients", b: D.patients.length + "" },
        { id: "calendar",  icon: <Icon.Calendar size={14} />,    l: "OT board" },
      ],
    },
    {
      h: "Tools", items: [
        { id: "templates", icon: <Icon.Pill size={14} />,        l: "Rx templates" },
        { id: "library",   icon: <Icon.MessageCircle size={14} />, l: "Education library" },
      ],
    },
  ] : [
    {
      h: "Insights", items: [
        { id: "admin",    icon: <Icon.Activity size={14} />, l: "Operations overview" },
        { id: "patients", icon: <Icon.Users size={14} />,    l: "Pipeline", b: D.patients.length + "" },
        { id: "billing",  icon: <Icon.Wallet size={14} />,   l: "Revenue" },
      ],
    },
    {
      h: "Team", items: [
        { id: "doctors",  icon: <Icon.Stethoscope size={14} />, l: "Doctors" },
        { id: "settings", icon: <Icon.Settings size={14} />,    l: "Clinic settings" },
      ],
    },
  ];

  return (
    <nav className="sidebar">
      {role === "frontdesk" && (
        <button className="btn primary" style={{ width: "100%", justifyContent: "center" }}
                onClick={openBooking}>
          <Icon.Plus size={14} /> New booking
        </button>
      )}
      {role === "doctor" && (
        <button className="btn primary" style={{ width: "100%", justifyContent: "center" }}
                onClick={() => go({ view: "consult", id: "p-001" })}>
          <Icon.Stethoscope size={14} /> Start consult
        </button>
      )}

      {groups.map((g, i) => (
        <div className="nav-group" key={i}>
          <h6>{g.h}</h6>
          {g.items.map(it => (
            <button key={it.id} className={"nav-item" + (route.view === it.id ? " active" : "")}
                    onClick={() => go({ view: it.id })}>
              <span className="ni-icon">{it.icon}</span>
              <span>{it.l}</span>
              {it.b ? <span className="ni-badge">{it.b}</span> : null}
            </button>
          ))}
        </div>
      ))}

      <div className="sidebar-footer">
        <b>Kaayantar, Sindhu Bhavan Rd</b>
        <div style={{ marginTop: 2 }}>Open · 10:00 – 19:00</div>
        <div style={{ marginTop: 6, display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: 3, background: "var(--ok-fg)" }} className="pulse" />
          WhatsApp Business · connected
        </div>
      </div>
    </nav>
  );
}

// ============================================================
// Placeholder views (calendar, messages, etc — not in scope but reachable)
// ============================================================
function PlaceholderView({ view }) {
  const titles = {
    calendar: ["Calendar", "Daily / weekly views, OT board, blocked time, recurring blocks"],
    messages: ["WhatsApp inbox", "Threaded conversations, broadcast templates, delivery analytics"],
    billing:  ["Billing & Revenue", "Per-doctor collections, GST reports, refunds, monthly P&L"],
    settings: ["Settings", "Clinic, doctors, fee schedule, integrations, roles"],
  };
  const [t, sub] = titles[view] || [view, ""];
  return (
    <div>
      <div className="canvas-head">
        <div>
          <h1>{t}</h1>
          <p>{sub}</p>
        </div>
        <div className="actions">
          <button className="btn"><Icon.Plus size={14} /> Add</button>
        </div>
      </div>
      <div className="card">
        <div className="empty" style={{ padding: 60 }}>
          <div style={{ fontFamily: "var(--f-display)", fontSize: 22, fontWeight: 500, color: "var(--text)", marginBottom: 4 }}>
            Coming in the next sprint
          </div>
          <div style={{ maxWidth: 520, margin: "0 auto" }}>
            This area is wired into the same data layer as the rest of the app. The first prototype focuses on the booking flow, patient profile, consult tools, and CRM strip. {sub}
          </div>
          <div style={{ marginTop: 16, display: "flex", gap: 6, justifyContent: "center" }}>
            <Badge kind="brand">Designed</Badge>
            <Badge>Not built yet</Badge>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Mount
// ============================================================
ReactDOM.createRoot(document.getElementById("root")).render(<App />);
