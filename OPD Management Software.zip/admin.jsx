// admin.jsx — Admin view: a CRM-style overview dashboard (lead funnel + cohort tables)

const Admin = {};

Admin.Dashboard = function ({ go }) {
  const D = window.KAAYANTAR_DATA;
  return (
    <div>
      <div className="canvas-head">
        <div>
          <h1>Kaayantar — May 2026</h1>
          <p>Live view across OPD, CRM, and procedures · {D.patients.length} active patients · 3 clinics</p>
        </div>
        <div className="actions">
          <div className="seg">
            <button>7d</button>
            <button className="on">30d</button>
            <button>Quarter</button>
            <button>Year</button>
          </div>
          <button className="btn"><Icon.Send size={14} /> Export</button>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 14 }}>
        <Stat label="Total leads"     value="412" delta={+38}   icon={<Icon.Sparkles size={70} />} accent="#1F4D44" />
        <Stat label="OPDs booked"     value="286" delta={+22}   icon={<Icon.Calendar size={70} />} accent="#3D6E63" />
        <Stat label="Procedures"      value="64"  delta={+9}    icon={<Icon.Heart size={70} />} accent="#B87A3A" />
        <Stat label="Revenue" unit="₹" value="2.42 Cr" delta={+0.4}  icon={<Icon.Wallet size={70} />} accent="#8E5A23" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 14, marginBottom: 14 }}>
        <div className="card">
          <div className="card-title">
            <h3>Lead → IPD funnel</h3>
            <span className="sub">Last 30 days</span>
          </div>
          <FunnelChart />
        </div>
        <div className="card">
          <div className="card-title"><h3>Cycle time benchmarks</h3></div>
          <BenchRow l="Lead → OPD"        v="4.2 days" delta="-0.6" good />
          <BenchRow l="OPD → Surgery sugg." v="2.0 days" delta="±0"  good />
          <BenchRow l="Surgery sugg. → IPD" v="18.4 days" delta="+1.2" />
          <BenchRow l="IPD → Discharge"     v="2.6 days" delta="-0.3" good />
          <BenchRow l="Post-op review compliance" v="92%" delta="+4" good />
        </div>
      </div>

      <div className="card">
        <div className="card-title">
          <h3>Patient pipeline</h3>
          <div style={{ display: "flex", gap: 6 }}>
            <button className="btn sm"><Icon.Filter size={12} /> Filter</button>
            <button className="btn sm">CSV</button>
          </div>
        </div>
        <table className="tbl">
          <thead><tr><th>Patient</th><th>Stage</th><th>Doctor</th><th>Lead source</th><th>Lead → OPD</th><th>OPD → IPD</th><th>Value</th></tr></thead>
          <tbody>
            {D.patients.map(p => {
              const c = new Date(p.lead.createdAt);
              const o = new Date(p.lead.firstOpdAt);
              const leadToOpd = Math.round((o - c) / 86400000);
              const opdToIpd = p.surgery.suggested && p.surgery.date ? Math.round((new Date(p.surgery.date) - o) / 86400000) : null;
              return (
                <tr key={p.id}>
                  <td>
                    <div className="pt-cell">
                      <Avatar name={p.name} size="sm" />
                      <div><div className="name">{p.name}</div>
                        <div className="meta">{p.age}y · {p.city}</div></div>
                    </div>
                  </td>
                  <td><PipelineBadge status={p.status} /></td>
                  <td>{doctorById(p.visit.doctor).name}</td>
                  <td><Badge>{p.lead.source}</Badge></td>
                  <td style={{ fontFamily: "var(--f-mono)" }}>{leadToOpd}d</td>
                  <td style={{ fontFamily: "var(--f-mono)" }}>{opdToIpd != null ? opdToIpd + "d" : "—"}</td>
                  <td style={{ fontFamily: "var(--f-mono)", fontWeight: 500 }}>{p.surgery.suggested ? inr(p.surgery.packageInr) : "—"}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

function FunnelChart() {
  const D = window.KAAYANTAR_DATA;
  const max = D.funnelDistribution[0].value;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {D.funnelDistribution.map((f, i) => {
        const pct = (f.value / max) * 100;
        const conv = i > 0 ? ((f.value / D.funnelDistribution[i - 1].value) * 100).toFixed(0) : null;
        return (
          <div key={f.label} style={{ display: "grid", gridTemplateColumns: "140px 1fr 80px 70px", gap: 10, alignItems: "center" }}>
            <span style={{ fontSize: 12.5, fontWeight: 500 }}>{f.label}</span>
            <div style={{ height: 26, background: "var(--bg-sunken)", borderRadius: 6, overflow: "hidden", position: "relative" }}>
              <div style={{
                height: "100%", width: `${pct}%`,
                background: `linear-gradient(90deg, hsl(${165 - i * 8} ${48 - i * 4}% ${30 + i * 5}%), hsl(${30 + i * 2} 40% 50%))`,
                display: "flex", alignItems: "center", paddingLeft: 10,
                fontSize: 11.5, color: "#fff", fontWeight: 500, fontFamily: "var(--f-mono)",
              }}>{f.value}</div>
            </div>
            <div style={{ fontSize: 11, color: "var(--text-mute)", fontFamily: "var(--f-mono)" }}>{pct.toFixed(0)}%</div>
            <div style={{ fontSize: 11, color: conv && +conv >= 70 ? "var(--ok-fg)" : "var(--text-mute)", fontFamily: "var(--f-mono)" }}>
              {conv ? `→ ${conv}%` : "—"}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function BenchRow({ l, v, delta, good }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: "1px dashed var(--line)", fontSize: 12.5 }}>
      <span>{l}</span>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontFamily: "var(--f-mono)", fontWeight: 500 }}>{v}</span>
        <span style={{ fontSize: 10.5, color: good ? "var(--ok-fg)" : "var(--text-mute)", fontFamily: "var(--f-mono)" }}>{delta}</span>
      </div>
    </div>
  );
}

function PipelineBadge({ status }) {
  const map = {
    "checked-in":      ["ok",     "OPD today"],
    "waiting":         ["warn",   "Waiting"],
    "post-op-day-22":  ["info",   "Post-op"],
    "surgery-planned": ["accent", "Surgery planned"],
    "estimate-shared": ["info",   "Estimate sent"],
    "pre-op-prep":     ["warn",   "Pre-op prep"],
  };
  const [k, label] = map[status] || ["default", status];
  return <Badge kind={k} dot>{label}</Badge>;
}

Object.assign(window, { Admin });
