// patient-profile.jsx — Shared patient profile (Front Desk view + Surgery/Pre-op)
function PatientProfile({ id, go }) {
  const D = window.KAAYANTAR_DATA;
  const p = D.patients.find(x => x.id === id) || D.patients[0];
  const [tab, setTab] = useState("overview");
  const doc = doctorById(p.visit.doctor);
  const hosp = p.surgery.suggested ? D.hospitals.find(h => h.id === p.surgery.hospital) : null;
  const toast = useToast();
  const [surgeryModal, setSurgeryModal] = useState(false);

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: "var(--text-mute)", marginBottom: 10 }}>
        <button className="btn sm ghost" onClick={() => go({ view: "patients" })}>← Patients</button>
        <span>/</span>
        <span>{p.name}</span>
      </div>

      <div className="card" style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", gap: 18, alignItems: "center", padding: "18px 22px" }}>
        <Avatar name={p.name} size="lg" />
        <div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}>
            <h2 style={{ margin: 0, fontFamily: "var(--f-display)", fontSize: 28, fontWeight: 500 }}>{p.name}</h2>
            {p.tags.map(t => <Badge key={t} kind={t === "VIP" ? "accent" : t === "Insurance" ? "info" : t === "New" ? "brand" : "default"}>{t}</Badge>)}
          </div>
          <div style={{ fontSize: 12.5, color: "var(--text-mute)", marginTop: 4, display: "flex", gap: 14, flexWrap: "wrap" }}>
            <span>UHID <b style={{ color: "var(--text)", fontFamily: "var(--f-mono)" }}>K-{p.id.slice(-3).toUpperCase()}</b></span>
            <span>•</span>
            <span>{p.age}y · {p.sex} · DOB {p.dob}</span>
            <span>•</span>
            <span style={{ fontFamily: "var(--f-mono)" }}>{p.phone}</span>
            <span>•</span>
            <span>{p.city}</span>
          </div>
          <div style={{ fontSize: 12, color: "var(--text-mute)", marginTop: 6, display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
            <span style={{ color: doc.color, fontWeight: 700 }}>●</span> Treating: <b style={{ color: "var(--text)", fontWeight: 500 }}>{doc.name}</b>
            <span>•</span>
            <span>Lead via <b style={{ color: "var(--text)", fontWeight: 500 }}>{p.lead.source}</b></span>
            <span>•</span>
            <span>{p.visit.count} OPD{p.visit.count > 1 ? "s" : ""}</span>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6, alignItems: "flex-end" }}>
          <button className="btn primary" onClick={() => toast.push({ kind: "wa", title: "WhatsApp opened", body: `${p.name} · ${p.phone}` })}>
            <Icon.MessageCircle size={14} /> WhatsApp
          </button>
          <button className="btn sm ghost"><Icon.Phone size={12} /> {p.phone}</button>
        </div>
      </div>

      <div style={{ display: "flex", gap: 4, margin: "14px 0", borderBottom: "1px solid var(--line)" }}>
        {[
          { id: "overview",   l: "Overview" },
          { id: "documents",  l: "Documents", n: p.docs.id + p.docs.reports + p.docs.photos + p.docs.consents },
          { id: "surgery",    l: "Surgery / Pre-op" },
          { id: "billing",    l: "Billing & Insurance" },
          { id: "timeline",   l: "Timeline" },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            border: 0, background: "transparent",
            padding: "10px 14px",
            borderBottom: tab === t.id ? "2px solid var(--brand)" : "2px solid transparent",
            color: tab === t.id ? "var(--text)" : "var(--text-mute)",
            fontSize: 13, fontWeight: 500, marginBottom: -1,
          }}>
            {t.l}{t.n ? <span style={{ marginLeft: 6, fontSize: 11, color: "var(--text-dim)" }}>{t.n}</span> : null}
          </button>
        ))}
      </div>

      {tab === "overview"  && <OverviewTab  p={p} go={go} />}
      {tab === "documents" && <DocsTab      p={p} />}
      {tab === "surgery"   && <SurgeryTab   p={p} hosp={hosp} onEdit={() => setSurgeryModal(true)} />}
      {tab === "billing"   && <BillingTab   p={p} />}
      {tab === "timeline"  && <TimelineTab  p={p} />}

      <Modal open={surgeryModal} onClose={() => setSurgeryModal(false)}
        title="Surgery plan" subtitle="Hospital, date and pre-op share">
        <SurgeryEditor p={p} hospitals={D.hospitals} procedures={D.procedures} />
      </Modal>
    </div>
  );
}

function OverviewTab({ p, go }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 14 }}>
      <div className="card">
        <div className="card-title">
          <h3>Consultation history</h3>
          <button className="btn sm">View all</button>
        </div>
        <div className="timeline">
          {p.history.map((h, i) => (
            <div className="tl-item" key={i}>
              <b>{new Date(h.date).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}</b>
              <span>{h.note}</span>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 14, padding: 12, background: "var(--bg-sunken)", borderRadius: 10, display: "flex", gap: 12, alignItems: "center" }}>
          <div style={{ width: 30, height: 30, borderRadius: 8, background: "var(--emerald-50)", color: "var(--emerald-700)", display: "grid", placeItems: "center" }}>
            <Icon.Calendar size={14} />
          </div>
          <div style={{ flex: 1, fontSize: 12.5 }}>
            <b>Next follow-up</b> — {new Date(p.visit.date).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" })} · {p.visit.time}
          </div>
          <button className="btn sm">Reschedule</button>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div className="card">
          <div className="card-title"><h3>Emergency contact</h3></div>
          <div style={{ fontSize: 13.5, fontWeight: 500 }}>{p.emergency.name}</div>
          <div style={{ fontFamily: "var(--f-mono)", fontSize: 12.5, color: "var(--text-mute)" }}>{p.emergency.phone}</div>
        </div>
        <div className="card">
          <div className="card-title"><h3>Insurance</h3></div>
          <div style={{ fontSize: 13.5 }}>{p.surgery.insurance || "—"}</div>
          <div style={{ fontSize: 11.5, color: "var(--text-mute)", marginTop: 4 }}>
            {p.surgery.insurance && p.surgery.insurance.toLowerCase().includes("pending") ? "TPA approval in progress" :
             p.surgery.insurance && p.surgery.insurance.toLowerCase() === "self-pay" ? "Patient is self-paying" : "Coverage active"}
          </div>
        </div>
        <div className="card">
          <div className="card-title"><h3>Lead funnel timing</h3></div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, fontSize: 12 }}>
            <FunnelRow l="Lead created"   v={new Date(p.lead.createdAt).toLocaleString("en-IN", { day: "numeric", month: "short" })} />
            <FunnelRow l="First OPD"      v={new Date(p.lead.firstOpdAt).toLocaleString("en-IN", { day: "numeric", month: "short" })}
                       sub={`${Math.round((new Date(p.lead.firstOpdAt) - new Date(p.lead.createdAt)) / 86400000)} days from lead`} />
            {p.surgery.suggested && p.surgery.date && (
              <FunnelRow l={p.surgery.done ? "Surgery done" : "Surgery scheduled"}
                         v={new Date(p.surgery.date).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                         sub={`${Math.round((new Date(p.surgery.date) - new Date(p.lead.firstOpdAt)) / 86400000)} days from first OPD`} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function FunnelRow({ l, v, sub }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", paddingBottom: 6, borderBottom: "1px dashed var(--line)" }}>
      <div>
        <div style={{ color: "var(--text-mute)" }}>{l}</div>
        {sub ? <div style={{ fontSize: 11, color: "var(--bronze-500)", fontFamily: "var(--f-mono)" }}>{sub}</div> : null}
      </div>
      <div style={{ fontFamily: "var(--f-mono)", fontWeight: 500 }}>{v}</div>
    </div>
  );
}

function DocsTab({ p }) {
  const folders = [
    { l: "ID Proofs",      n: p.docs.id,       icon: <Icon.Doc size={18} />, hint: "Aadhaar, PAN, Passport" },
    { l: "Medical reports", n: p.docs.reports, icon: <Icon.Activity size={18} />, hint: "Labs, imaging, ECG" },
    { l: "Photos",          n: p.docs.photos,  icon: <Icon.Image size={18} />, hint: "Clinical photographs, before/after" },
    { l: "Consents",        n: p.docs.consents, icon: <Icon.Pencil size={18} />, hint: "Signed surgical consents" },
    { l: "Prescriptions",   n: p.visit.count,  icon: <Icon.Pill size={18} />, hint: "Past Rx PDFs" },
    { l: "Invoices",        n: p.surgery.done ? 2 : 1, icon: <Icon.Receipt size={18} />, hint: "Receipts & estimates" },
  ];
  return (
    <div>
      <div className="card">
        <div className="card-title">
          <h3>Folders</h3>
          <div style={{ display: "flex", gap: 6 }}>
            <button className="btn sm"><Icon.Folder size={12} /> New folder</button>
            <button className="btn sm primary"><Icon.Upload size={12} /> Upload</button>
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
          {folders.map((fd, i) => (
            <div className="folder" key={i}>
              <div className="ico">{fd.icon}</div>
              <div className="meta">
                <b>{fd.l}</b>
                <span>{fd.n} file{fd.n === 1 ? "" : "s"} · {fd.hint}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="card" style={{ marginTop: 14 }}>
        <div className="card-title">
          <h3>Recent uploads</h3>
          <span style={{ fontSize: 11, color: "var(--text-mute)" }}>Drag-drop anywhere on this card to upload</span>
        </div>
        <table className="tbl">
          <thead><tr><th>File</th><th>Folder</th><th>Uploaded</th><th>Size</th><th></th></tr></thead>
          <tbody>
            <tr><td><Icon.Doc size={14} /> Aadhaar-front.jpg</td><td>ID Proofs</td><td style={{ color: "var(--text-mute)", fontFamily: "var(--f-mono)" }}>2026-05-08</td><td style={{ fontFamily: "var(--f-mono)" }}>820 KB</td><td><button className="btn sm ghost"><Icon.Eye size={12} /></button></td></tr>
            <tr><td><Icon.Activity size={14} /> CBC-report.pdf</td><td>Medical reports</td><td style={{ color: "var(--text-mute)", fontFamily: "var(--f-mono)" }}>2026-05-08</td><td style={{ fontFamily: "var(--f-mono)" }}>1.2 MB</td><td><button className="btn sm ghost"><Icon.Eye size={12} /></button></td></tr>
            <tr><td><Icon.Image size={14} /> profile-front.jpg</td><td>Photos</td><td style={{ color: "var(--text-mute)", fontFamily: "var(--f-mono)" }}>2026-05-09</td><td style={{ fontFamily: "var(--f-mono)" }}>2.4 MB</td><td><button className="btn sm ghost"><Icon.Eye size={12} /></button></td></tr>
            <tr><td><Icon.Image size={14} /> profile-side.jpg</td><td>Photos</td><td style={{ color: "var(--text-mute)", fontFamily: "var(--f-mono)" }}>2026-05-09</td><td style={{ fontFamily: "var(--f-mono)" }}>2.1 MB</td><td><button className="btn sm ghost"><Icon.Eye size={12} /></button></td></tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

function SurgeryTab({ p, hosp, onEdit }) {
  const toast = useToast();
  if (!p.surgery.suggested) {
    return (
      <div className="card">
        <div className="empty">
          <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 6 }}>No surgery suggested yet</div>
          <div className="helper" style={{ marginBottom: 14 }}>Doctor will mark this from the Doctor portal during consultation.</div>
          <button className="btn"><Icon.Plus size={12} /> Mark surgery suggested</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 14 }}>
      <div className="card">
        <div className="card-title">
          <h3>Surgical plan</h3>
          <button className="btn sm" onClick={onEdit}><Icon.Pencil size={12} /> Edit</button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 16 }}>
          <Field l="Procedure"  v={p.surgery.procedure} big />
          <Field l="Status"     v={p.surgery.done ? "Completed" : "Scheduled"} badge={p.surgery.done ? "ok" : "warn"} />
          <Field l="Hospital"   v={hosp.name} sub={hosp.kind + " · " + hosp.addr} />
          <Field l="Date & time" v={new Date(p.surgery.date).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "long" }) + " · " + p.surgery.time} />
          <Field l="Package"    v={inr(p.surgery.packageInr)} mono />
          <Field l="Coverage"   v={p.surgery.insurance} />
        </div>

        <div className="divider" />

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
          <div style={{ fontSize: 12.5, fontWeight: 600 }}>Pre-op instructions</div>
          <div style={{ display: "flex", gap: 6 }}>
            <button className="btn sm"><Icon.Upload size={12} /> Replace file</button>
            <button className="btn sm primary"
                    onClick={() => toast.push({ kind: "wa", title: "Pre-op shared", body: `${p.surgery.preopFile} sent to ${p.name}` })}>
              <Icon.MessageCircle size={12} /> Share on WhatsApp
            </button>
          </div>
        </div>

        <div style={{
          padding: 12, borderRadius: 10,
          background: "var(--bg-sunken)", display: "flex", alignItems: "center", gap: 12,
        }}>
          <div style={{
            width: 38, height: 48, borderRadius: 6,
            background: "linear-gradient(180deg, #fff 0%, #f3eee2 100%)",
            border: "1px solid var(--line-strong)",
            display: "grid", placeItems: "center",
            fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--bronze-600)",
          }}>PDF</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 500, fontSize: 13 }}>{p.surgery.preopFile}</div>
            <div style={{ fontSize: 11.5, color: "var(--text-mute)" }}>v3 · uploaded by Dr. Asmita · 04 May 2026</div>
          </div>
          <button className="btn sm"><Icon.Eye size={12} /> Preview</button>
        </div>

        <div style={{ marginTop: 12, fontSize: 12, color: "var(--text-mute)", display: "flex", gap: 8, alignItems: "flex-start", padding: 10, background: "var(--info-bg)", borderRadius: 8 }}>
          <Icon.MessageCircle size={14} />
          <span style={{ color: "var(--info-fg)" }}>
            Patient will receive a WhatsApp reminder with this PDF 48h, 24h, and 6h before procedure. Doctor's profile link is auto-attached.
          </span>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div className="card">
          <div className="card-title"><h3>Pre-op checklist</h3></div>
          <Check label="Anaesthesia clearance" done={p.surgery.done || p.id === "p-006"} />
          <Check label="Cardio echo & ECG"     done={p.surgery.done || p.id === "p-006"} />
          <Check label="HBA1c, CBC, LFT, KFT"  done={p.surgery.done} />
          <Check label="COVID-19 RT-PCR (24h)" done={p.surgery.done} />
          <Check label="Diet counselling"      done={p.surgery.done || p.id === "p-006"} />
          <Check label="Consent forms signed"  done={p.surgery.done} />
          <Check label="Photographs (front / side / 3-4)"  done={p.docs.photos > 0} />
          <Check label="Insurance pre-auth"    done={p.surgery.insurance && p.surgery.insurance.toLowerCase().includes("approved")} />
        </div>
        <div className="card">
          <div className="card-title"><h3>OT logistics</h3></div>
          <div style={{ fontSize: 12, lineHeight: 1.8 }}>
            <Field l="Anaesthetist" v="Dr. Mehul Vora" />
            <Field l="OT block"     v="OT-2 · 08:30 – 11:30" />
            <Field l="Admit by"     v="07:30, NPO from midnight" />
            <Field l="Estimated stay" v={p.surgery.procedure.includes("Sleeve") || p.surgery.procedure.includes("Bypass") ? "2 nights" : "Day-care / 1 night"} />
          </div>
        </div>
      </div>
    </div>
  );
}

function Check({ label, done }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 0", fontSize: 12.5 }}>
      <div style={{
        width: 18, height: 18, borderRadius: 5,
        background: done ? "var(--emerald-700)" : "transparent",
        border: "1.5px solid " + (done ? "var(--emerald-700)" : "var(--line-strong)"),
        display: "grid", placeItems: "center",
        color: "#fff",
      }}>{done ? <Icon.Check size={12} /> : null}</div>
      <span style={{ color: done ? "var(--text)" : "var(--text-mute)", textDecoration: done ? "none" : "none" }}>{label}</span>
    </div>
  );
}

function Field({ l, v, sub, big, mono, badge }) {
  return (
    <div>
      <div style={{ fontSize: 11, color: "var(--text-mute)", textTransform: "uppercase", letterSpacing: ".06em", fontWeight: 600 }}>{l}</div>
      <div style={{
        fontSize: big ? 18 : 13.5, fontWeight: big ? 500 : 500,
        fontFamily: mono ? "var(--f-mono)" : "inherit",
        marginTop: 4,
        display: "flex", alignItems: "center", gap: 6,
      }}>
        {v}
        {badge ? <Badge kind={badge}>{v === "Scheduled" ? "Upcoming" : v}</Badge> : null}
      </div>
      {sub ? <div style={{ fontSize: 11, color: "var(--text-mute)", marginTop: 2 }}>{sub}</div> : null}
    </div>
  );
}

function SurgeryEditor({ p, hospitals, procedures }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
      <div className="field"><label>Procedure</label>
        <select className="select" defaultValue={p.surgery.procedure}>
          {procedures.map(pr => <option key={pr}>{pr}</option>)}
        </select>
      </div>
      <div className="field"><label>Hospital / OT</label>
        <select className="select" defaultValue={p.surgery.hospital}>
          {hospitals.map(h => <option key={h.id} value={h.id}>{h.name} — {h.kind}</option>)}
        </select>
      </div>
      <div className="field"><label>Date</label>
        <input className="input" type="date" defaultValue={p.surgery.date} />
      </div>
      <div className="field"><label>Time</label>
        <input className="input" type="time" defaultValue={p.surgery.time} />
      </div>
      <div className="field"><label>Package (₹)</label>
        <input className="input" defaultValue={p.surgery.packageInr} />
      </div>
      <div className="field"><label>Insurance / coverage</label>
        <input className="input" defaultValue={p.surgery.insurance} />
      </div>
      <div className="field" style={{ gridColumn: "1 / -1" }}>
        <label>Pre-op instructions (PDF)</label>
        <div style={{
          border: "2px dashed var(--line-strong)", borderRadius: 10,
          padding: 24, textAlign: "center", color: "var(--text-mute)",
          background: "var(--bg-sunken)",
        }}>
          <Icon.Upload size={20} />
          <div style={{ marginTop: 6, fontSize: 13 }}>Drop the latest pre-op PDF here, or click to browse</div>
          <div style={{ fontSize: 11, marginTop: 4 }}>Current: {p.surgery.preopFile}</div>
        </div>
      </div>
    </div>
  );
}

function BillingTab({ p }) {
  const items = p.surgery.suggested ? [
    { d: "2026-05-08", l: "OPD Consultation",        amt: 1500, by: "QR",   r: "KAY-2026-05-104" },
    { d: "2026-05-09", l: "Pre-op investigations",   amt: 8500, by: "Link", r: "KAY-2026-05-128" },
    { d: "2026-05-12", l: "Surgery advance",         amt: 50000, by: "Link", r: "KAY-2026-05-201", pending: true },
  ] : [
    { d: "2026-05-16", l: "OPD Consultation", amt: 1500, by: "QR", r: "KAY-2026-05-318" },
  ];
  const total = items.reduce((a, i) => a + (i.pending ? 0 : i.amt), 0);
  const pending = items.reduce((a, i) => a + (i.pending ? i.amt : 0), 0);
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 14 }}>
      <div className="card">
        <div className="card-title">
          <h3>Payments</h3>
          <button className="btn sm primary"><Icon.Plus size={12} /> Add payment</button>
        </div>
        <table className="tbl">
          <thead><tr><th>Date</th><th>Item</th><th>Mode</th><th>Receipt</th><th style={{ textAlign: "right" }}>Amount</th></tr></thead>
          <tbody>
            {items.map((it, i) => (
              <tr key={i}>
                <td style={{ fontFamily: "var(--f-mono)", color: "var(--text-mute)" }}>{it.d}</td>
                <td>{it.l} {it.pending ? <Badge kind="warn">Pending</Badge> : null}</td>
                <td><Badge>{it.by}</Badge></td>
                <td style={{ fontFamily: "var(--f-mono)", fontSize: 11.5, color: "var(--text-mute)" }}>{it.r}</td>
                <td style={{ textAlign: "right", fontFamily: "var(--f-mono)", fontWeight: 500 }}>{inr(it.amt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div className="card">
          <div className="card-title"><h3>Account summary</h3></div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <SumRow l="Package estimate" v={inr(p.surgery.packageInr || 0)} />
            <SumRow l="Paid till date"   v={inr(total)} />
            <SumRow l="Pending"          v={inr((p.surgery.packageInr || 0) - total - pending)} />
            <div className="divider" />
            <SumRow l="Due now" v={inr(pending)} />
          </div>
          <button className="btn primary" style={{ width: "100%", marginTop: 12 }}>
            <Icon.MessageCircle size={12} /> Send payment link
          </button>
        </div>
        <div className="card">
          <div className="card-title"><h3>Insurance</h3></div>
          <div style={{ fontSize: 13 }}>{p.surgery.insurance || "—"}</div>
          {p.surgery.insurance && p.surgery.insurance.includes("approved") &&
            <Badge kind="ok" dot>Pre-auth approved</Badge>}
          {p.surgery.insurance && p.surgery.insurance.includes("pending") &&
            <Badge kind="warn" dot>TPA pending</Badge>}
        </div>
      </div>
    </div>
  );
}

function TimelineTab({ p }) {
  const events = [
    { t: p.lead.createdAt,   k: "lead",      title: "Lead created", body: "Source: " + p.lead.source },
    { t: p.lead.firstOpdAt,  k: "opd",       title: "First OPD",    body: "₹1,500 collected via QR" },
    ...(p.history.length > 1 ? [{ t: p.history[1].date + "T11:00:00", k: "opd", title: "Follow-up", body: p.history[1].note }] : []),
    ...(p.surgery.suggested ? [{ t: p.history[0].date + "T11:30:00", k: "surg", title: "Surgery suggested", body: p.surgery.procedure + " · " + (p.surgery.insurance) }] : []),
    ...(p.surgery.suggested && p.surgery.date ? [{ t: p.surgery.date + "T" + p.surgery.time, k: p.surgery.done ? "done" : "sched", title: p.surgery.done ? "Surgery completed" : "Surgery scheduled", body: (window.KAAYANTAR_DATA.hospitals.find(h => h.id === p.surgery.hospital).name) }] : []),
  ];
  events.sort((a, b) => new Date(a.t) - new Date(b.t));
  return (
    <div className="card">
      <div className="card-title"><h3>Patient journey</h3></div>
      <div className="timeline">
        {events.map((e, i) => (
          <div className="tl-item" key={i} style={{
            "--c": e.k === "surg" ? "#B87A3A" : e.k === "done" ? "#1F6B2A" : "#1F4D44",
          }}>
            <b>{e.title}</b>
            <span>{new Date(e.t).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })} — {e.body}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { PatientProfile });
