// anatomy.jsx — Pre-loaded SVG anatomy templates for the drawing board.
// All templates use viewBox "0 0 400 500".

const Anatomy = {
  blank: () => null,

  face: () => (
    <g stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.7">
      <ellipse cx="200" cy="240" rx="105" ry="140" />
      <path d="M105 200 Q200 70 295 200" />
      <ellipse cx="158" cy="232" rx="18" ry="9" />
      <ellipse cx="242" cy="232" rx="18" ry="9" />
      <circle cx="158" cy="232" r="3" fill="currentColor" />
      <circle cx="242" cy="232" r="3" fill="currentColor" />
      <path d="M138 210 Q158 202 178 210" />
      <path d="M222 210 Q242 202 262 210" />
      <path d="M200 240 Q188 290 195 310 Q200 318 210 310 Q220 295 200 240" />
      <path d="M188 305 Q200 318 212 305" />
      <path d="M170 345 Q200 335 230 345 Q200 360 170 345 Z" />
      <path d="M170 345 L200 350 L230 345" />
      <path d="M170 365 Q200 380 230 365" strokeDasharray="3 3" />
      <path d="M95 240 Q85 270 100 285" />
      <path d="M305 240 Q315 270 300 285" />
      <text x="50" y="40" fontSize="11" fontFamily="sans-serif" fill="currentColor" opacity="0.6">Frontal view — face</text>
    </g>
  ),

  nose: () => (
    <g stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.7">
      <path d="M120 80 Q120 140 145 200 Q160 240 165 275 Q166 295 195 310 Q235 320 270 305 Q275 295 270 280 Q260 268 240 265 Q220 260 210 240 Q205 225 215 215 Q230 220 240 215 Q250 210 245 195 Q240 175 220 160 Q200 135 180 100 Q165 80 150 70 Q130 70 120 80 Z" />
      <path d="M215 215 Q205 230 195 250 Q185 270 195 280" />
      <path d="M220 275 Q240 285 260 290" strokeDasharray="3 3" />
      <circle cx="245" cy="275" r="5" />
      <path d="M210 215 L195 215" strokeDasharray="2 2" />
      <text x="50" y="40" fontSize="11" fontFamily="sans-serif" fill="currentColor" opacity="0.6">Lateral profile — rhinoplasty planning</text>
      <text x="280" y="200" fontSize="9" fontFamily="sans-serif" fill="currentColor" opacity="0.5">Dorsum</text>
      <text x="280" y="265" fontSize="9" fontFamily="sans-serif" fill="currentColor" opacity="0.5">Tip</text>
    </g>
  ),

  abdomen: () => (
    <g stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.7">
      <path d="M120 60 Q200 50 280 60 Q295 80 290 200 Q300 320 290 420 Q260 460 200 460 Q140 460 110 420 Q100 320 110 200 Q105 80 120 60 Z" />
      <ellipse cx="200" cy="270" rx="6" ry="9" fill="currentColor" opacity="0.4" />
      <path d="M180 180 Q200 200 220 180" opacity="0.4" />
      <path d="M170 230 Q200 250 230 230" opacity="0.4" />
      <path d="M175 320 Q200 335 225 320" opacity="0.4" />
      <text x="180" y="320" fontSize="9" fontFamily="sans-serif" fill="currentColor" opacity="0.5">Abs ref</text>
      {/* Liposuction zones */}
      <ellipse cx="155" cy="280" rx="28" ry="55" strokeDasharray="4 3" stroke="#B87A3A" />
      <ellipse cx="245" cy="280" rx="28" ry="55" strokeDasharray="4 3" stroke="#B87A3A" />
      <ellipse cx="200" cy="370" rx="60" ry="35" strokeDasharray="4 3" stroke="#B87A3A" />
      <text x="115" y="270" fontSize="9" fontFamily="sans-serif" fill="#B87A3A">Flank L</text>
      <text x="265" y="270" fontSize="9" fontFamily="sans-serif" fill="#B87A3A">Flank R</text>
      <text x="170" y="380" fontSize="9" fontFamily="sans-serif" fill="#B87A3A">Lower abdomen</text>
      <text x="50" y="40" fontSize="11" fontFamily="sans-serif" fill="currentColor" opacity="0.6">Abdomen — Liposuction zones</text>
    </g>
  ),

  breast: () => (
    <g stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.7">
      <path d="M50 100 Q80 80 130 100 Q200 130 270 100 Q320 80 350 100 L355 200 Q340 320 200 350 Q60 320 45 200 Z" />
      <line x1="200" y1="60" x2="200" y2="350" strokeDasharray="3 3" opacity="0.4" />
      {/* Left breast */}
      <ellipse cx="140" cy="210" rx="60" ry="65" />
      <circle cx="140" cy="210" r="14" fill="currentColor" opacity="0.18" />
      <circle cx="140" cy="210" r="5" fill="currentColor" opacity="0.45" />
      {/* Right breast */}
      <ellipse cx="260" cy="210" rx="60" ry="65" />
      <circle cx="260" cy="210" r="14" fill="currentColor" opacity="0.18" />
      <circle cx="260" cy="210" r="5" fill="currentColor" opacity="0.45" />
      {/* Markings */}
      <path d="M90 210 L190 210" strokeDasharray="2 2" stroke="#B87A3A" />
      <path d="M210 210 L310 210" strokeDasharray="2 2" stroke="#B87A3A" />
      <path d="M140 145 L140 275" strokeDasharray="2 2" stroke="#B87A3A" />
      <path d="M260 145 L260 275" strokeDasharray="2 2" stroke="#B87A3A" />
      <text x="50" y="40" fontSize="11" fontFamily="sans-serif" fill="currentColor" opacity="0.6">Breast — markings & IMF</text>
    </g>
  ),

  bodyF: () => (
    <g stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.7">
      {/* Head */}
      <ellipse cx="200" cy="55" rx="28" ry="34" />
      {/* Neck + shoulders */}
      <path d="M185 86 Q185 100 175 110 Q140 120 120 140 L100 160" />
      <path d="M215 86 Q215 100 225 110 Q260 120 280 140 L300 160" />
      {/* Torso */}
      <path d="M100 160 Q105 220 130 280 Q140 305 145 340" />
      <path d="M300 160 Q295 220 270 280 Q260 305 255 340" />
      {/* Bust */}
      <path d="M150 175 Q170 210 175 220" />
      <path d="M250 175 Q230 210 225 220" />
      {/* Waist curve */}
      <path d="M145 240 Q200 250 255 240" strokeDasharray="2 2" opacity="0.4" />
      {/* Hips */}
      <path d="M145 340 Q160 360 165 380" />
      <path d="M255 340 Q240 360 235 380" />
      {/* Legs */}
      <path d="M165 380 Q160 460 158 480" />
      <path d="M200 365 L200 480" strokeDasharray="2 2" opacity="0.3" />
      <path d="M235 380 Q240 460 242 480" />
      <path d="M170 380 Q180 460 188 480" />
      <path d="M230 380 Q220 460 212 480" />
      {/* Arms */}
      <path d="M120 140 Q110 220 115 280" />
      <path d="M280 140 Q290 220 285 280" />
      <text x="50" y="40" fontSize="11" fontFamily="sans-serif" fill="currentColor" opacity="0.6">Body silhouette — female (anterior)</text>
    </g>
  ),

  bodyM: () => (
    <g stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.7">
      <ellipse cx="200" cy="55" rx="30" ry="36" />
      <path d="M180 88 Q180 105 165 115 Q120 125 95 150 L80 175" />
      <path d="M220 88 Q220 105 235 115 Q280 125 305 150 L320 175" />
      <path d="M80 175 Q90 230 100 280 Q115 320 130 360" />
      <path d="M320 175 Q310 230 300 280 Q285 320 270 360" />
      {/* Chest */}
      <path d="M130 175 Q170 200 195 195" />
      <path d="M270 175 Q230 200 205 195" />
      <line x1="200" y1="180" x2="200" y2="280" strokeDasharray="2 2" opacity="0.35" />
      {/* Abs */}
      <path d="M180 220 Q200 225 220 220" opacity="0.3" />
      <path d="M180 250 Q200 255 220 250" opacity="0.3" />
      <path d="M180 280 Q200 285 220 280" opacity="0.3" />
      {/* Legs */}
      <path d="M130 360 Q125 470 130 490" />
      <path d="M270 360 Q275 470 270 490" />
      <path d="M165 360 Q170 470 168 490" />
      <path d="M235 360 Q230 470 232 490" />
      {/* Arms */}
      <path d="M95 150 Q80 230 85 290" />
      <path d="M305 150 Q320 230 315 290" />
      <text x="50" y="40" fontSize="11" fontFamily="sans-serif" fill="currentColor" opacity="0.6">Body silhouette — male (anterior)</text>
    </g>
  ),

  sleeve: () => (
    <g stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.8">
      {/* Original stomach (light, dashed remnant) */}
      <path d="M150 130 Q120 160 115 220 Q120 290 165 340 Q220 370 250 340 Q280 290 270 220 Q260 170 230 140 Q200 125 175 130 Q160 125 150 130 Z"
            stroke="#999" strokeDasharray="3 4" />
      {/* Esophagus */}
      <path d="M195 60 L195 130" strokeWidth="3" />
      <text x="208" y="100" fontSize="9" fontFamily="sans-serif" fill="currentColor" opacity="0.7">Esophagus</text>
      {/* New sleeve (banana-shape) */}
      <path d="M180 130 Q165 160 162 220 Q170 290 200 340 Q220 350 230 340 Q240 290 232 220 Q225 170 210 140 Q200 125 185 130 Q180 128 180 130 Z"
            fill="#1F4D44" fillOpacity="0.08" stroke="#1F4D44" strokeWidth="1.5" />
      {/* Removed portion (hatched) */}
      <path d="M150 130 Q120 160 115 220 Q120 290 165 340 L200 340 Q170 290 162 220 Q165 160 180 130 Z"
            fill="#B87A3A" fillOpacity="0.12" stroke="#B87A3A" strokeDasharray="4 3" />
      <text x="100" y="240" fontSize="10" fontFamily="sans-serif" fill="#B87A3A">Removed</text>
      <text x="100" y="252" fontSize="10" fontFamily="sans-serif" fill="#B87A3A">~80%</text>
      <text x="252" y="240" fontSize="10" fontFamily="sans-serif" fill="#1F4D44">Sleeve</text>
      <text x="252" y="252" fontSize="10" fontFamily="sans-serif" fill="#1F4D44">remains</text>
      {/* Pylorus */}
      <path d="M230 340 Q260 360 290 400" strokeWidth="3" />
      <text x="300" y="400" fontSize="9" fontFamily="sans-serif" fill="currentColor" opacity="0.7">→ Duodenum</text>
      <text x="50" y="40" fontSize="11" fontFamily="sans-serif" fill="currentColor" opacity="0.6">Sleeve Gastrectomy — schematic</text>
    </g>
  ),

  rygb: () => (
    <g stroke="currentColor" strokeWidth="1.3" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.8">
      {/* Esophagus */}
      <path d="M200 50 L200 110" strokeWidth="3" />
      {/* Small upper gastric pouch */}
      <path d="M170 110 Q160 130 165 150 Q180 165 200 165 Q220 165 230 150 Q235 130 230 110 Z"
            fill="#1F4D44" fillOpacity="0.18" stroke="#1F4D44" strokeWidth="1.6" />
      <text x="100" y="135" fontSize="9" fontFamily="sans-serif" fill="#1F4D44">Pouch (30ml)</text>
      {/* Bypassed remnant stomach */}
      <path d="M255 130 Q300 145 310 200 Q310 270 280 310 Q250 320 240 290 Q235 240 240 180 Q245 135 255 130 Z"
            fill="#999" fillOpacity="0.15" stroke="#999" strokeDasharray="3 3" />
      <text x="305" y="220" fontSize="9" fontFamily="sans-serif" fill="#666">Bypassed</text>
      <text x="305" y="232" fontSize="9" fontFamily="sans-serif" fill="#666">stomach</text>
      {/* Roux limb (alimentary) */}
      <path d="M195 165 Q140 200 130 270 Q140 330 180 360 L200 360" strokeWidth="2" stroke="#1F4D44" />
      <text x="60" y="320" fontSize="9" fontFamily="sans-serif" fill="#1F4D44">Roux limb</text>
      {/* Biliopancreatic limb */}
      <path d="M280 310 Q260 340 230 360 L200 360" strokeWidth="2" stroke="#B87A3A" />
      <text x="245" y="345" fontSize="9" fontFamily="sans-serif" fill="#B87A3A">BP limb</text>
      {/* Common channel */}
      <circle cx="200" cy="360" r="6" fill="#1F4D44" />
      <text x="210" y="365" fontSize="9" fontFamily="sans-serif" fill="currentColor" opacity="0.7">Y-anastomosis</text>
      <path d="M200 360 Q210 410 200 460" strokeWidth="3" />
      <text x="210" y="440" fontSize="9" fontFamily="sans-serif" fill="currentColor" opacity="0.7">Common channel</text>
      <text x="50" y="40" fontSize="11" fontFamily="sans-serif" fill="currentColor" opacity="0.6">Roux-en-Y Gastric Bypass — schematic</text>
    </g>
  ),

  bmi: () => (
    <g stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.8">
      <text x="50" y="40" fontSize="11" fontFamily="sans-serif" fill="currentColor" opacity="0.6">BMI &amp; Comorbidity map</text>
      {/* BMI ladder */}
      <line x1="60" y1="80" x2="60" y2="460" strokeWidth="2" />
      {[
        { y: 90, l: "≥50", t: "Super-obese", c: "#8B2F22" },
        { y: 150, l: "40-50", t: "Morbid obesity", c: "#B05A30" },
        { y: 220, l: "35-40", t: "Severe", c: "#B87A3A" },
        { y: 280, l: "30-35", t: "Obese", c: "#C9A55A" },
        { y: 340, l: "25-30", t: "Overweight", c: "#7BA17C" },
        { y: 400, l: "18-25", t: "Healthy", c: "#1F4D44" },
      ].map((b, i) => (
        <g key={i}>
          <line x1="55" y1={b.y} x2="65" y2={b.y} strokeWidth="2" />
          <text x="72" y={b.y + 4} fontSize="11" fontFamily="sans-serif" fill={b.c} fontWeight="600">{b.l}</text>
          <text x="120" y={b.y + 4} fontSize="10" fontFamily="sans-serif" fill="currentColor" opacity="0.7">{b.t}</text>
        </g>
      ))}
      <text x="40" y="76" fontSize="9" fontFamily="sans-serif" fill="currentColor" opacity="0.6">BMI</text>
      {/* Comorbidities boxes */}
      <g>
        <rect x="240" y="100" width="130" height="32" rx="6" fill="#B87A3A" fillOpacity="0.12" stroke="#B87A3A" />
        <text x="252" y="118" fontSize="10" fontFamily="sans-serif" fill="#8E5A23">☐ Type 2 Diabetes</text>
        <text x="252" y="128" fontSize="9" fontFamily="sans-serif" fill="#8E5A23" opacity="0.7">HbA1c trend ↓</text>

        <rect x="240" y="140" width="130" height="32" rx="6" fill="#8B2F22" fillOpacity="0.1" stroke="#8B2F22" />
        <text x="252" y="158" fontSize="10" fontFamily="sans-serif" fill="#8B2F22">☐ Hypertension</text>

        <rect x="240" y="180" width="130" height="32" rx="6" fill="#1F4D44" fillOpacity="0.1" stroke="#1F4D44" />
        <text x="252" y="198" fontSize="10" fontFamily="sans-serif" fill="#1F4D44">☐ OSA / Sleep apnoea</text>

        <rect x="240" y="220" width="130" height="32" rx="6" fill="#1F4D44" fillOpacity="0.1" stroke="#1F4D44" />
        <text x="252" y="238" fontSize="10" fontFamily="sans-serif" fill="#1F4D44">☐ Dyslipidemia</text>

        <rect x="240" y="260" width="130" height="32" rx="6" fill="#1F4D44" fillOpacity="0.1" stroke="#1F4D44" />
        <text x="252" y="278" fontSize="10" fontFamily="sans-serif" fill="#1F4D44">☐ PCOS / Fertility</text>
      </g>
      {/* Arrow pointing patient marker */}
      <circle cx="60" cy="200" r="7" fill="#B87A3A" />
      <text x="78" y="195" fontSize="10" fontFamily="sans-serif" fill="#B87A3A" fontWeight="600">Patient · BMI 41</text>
    </g>
  ),
};

Object.assign(window, { Anatomy });
