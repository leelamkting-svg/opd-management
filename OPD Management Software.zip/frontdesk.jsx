// frontdesk.jsx — Front Desk portal views (Dashboard, Booking modal, Patient list, Patient profile)
const FD = {};

// =====================================================================
// Dashboard
// =====================================================================
FD.Dashboard = function ({ go, openBooking }) {
  const D = window.KAAYANTAR_DATA;
  return (
    <div>
      <div className="canvas-head">
        <div>
          <h1>Good morning, Asmita</h1>
          <p>Saturday, 16 May 2026 · Kaayantar, Sindhu Bhavan Road</p>
        </div>
        <div className="actions">
          <button className="btn"><Icon.Filter size={14} /> Filter</button>
          <button className="btn primary" onClick={openBooking}>
            <Icon.Plus size={14} /> New booking
          </button>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        <Stat label="Today's OPD" value="6" delta={+1} icon={<Icon.Calendar size={70} />} accent="#1F4D44" />
        <Stat label="New patients" value="2" delta={+2} icon={<Icon.UserPlus size={70} />} accent="#B87A3A" />
        <Stat label="Collections" unit="₹" value="6,000" delta={-1500} icon={<Icon.Wallet size={70} />} accent="#2C594F" />
        <Stat label="Surgery planned" value="4" delta={+1} icon={<Icon.Heart size={70} />} accent="#8E5A23" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 14 }}>
        <div className="card">
          <div className="card-title">
            <h3>Today's queue</h3>
            <div className="seg">
              <button className="on">All</button>
              <button>Dr. P.S.</button>
              <button>Dr. APK</button>
              <button>Dr. NV</button>
            </div>
          </div>
          <table className="tbl">
            <thead>
              <tr>
                <th>Time</th><th>Patient</th><th>Doctor</th><th>Type</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {D.todaysAppts.map(a => {
                const p = D.patients.find(x => x.id === a.pid);
                const doc = doctorById(a.doctor);
                return (
                  <tr key={a.pid}>
                    <td style={{ fontFamily: "var(--f-mono)", fontWeight: 500 }}>{a.time}</td>
                    <td>
                      <div className="pt-cell">
                        <Avatar name={a.name} size="sm" />
                        <div>
                          <div className="name">{a.name}</div>
                          <div className="meta">{p.age}y · {p.sex} · {p.city}</div>
                        </div>
                      </div>
                    </td>
                    <td><span style={{ color: doc.color, fontWeight: 700 }}>●</span> {doc.name}</td>
                    <td>{a.type === "new"
                      ? <Badge kind="accent">New OPD</Badge>
                      : <Badge kind="brand">Follow-up #{p.visit.count}</Badge>}</td>
                    <td><FdStatusBadge status={a.status} /></td>
                    <td style={{ textAlign: "right" }}>
                      <button className="btn sm ghost" onClick={() => go({ view: "patient", id: a.pid })}>
                        Open <Icon.Right size={12} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="card">
            <div className="card-title"><h3>Pending actions</h3></div>
            <ActionList />
          </div>
          <div className="card">
            <div className="card-title"><h3>Lead source · this week</h3></div>
            <LeadSourceBars />
          </div>
        </div>
      </div>
    </div>
  );
};

function FdStatusBadge({ status }) {
  const map = {
    "checked-in":      ["ok",     "Checked in"],
    "waiting":         ["warn",   "Waiting"],
    "post-op-day-22":  ["info",   "Post-op D+22"],
    "surgery-planned": ["accent", "Surgery planned"],
    "estimate-shared": ["info",   "Estimate shared"],
    "pre-op-prep":     ["warn",   "Pre-op prep"],
  };
  const [k, label] = map[status] || ["default", status];
  return <Badge kind={k} dot>{label}</Badge>;
}

function ActionList() {
  const items = [
    { icon: <Icon.MessageCircle size={14} />, color: "#075E54", title: "Send pre-op reminder", body: "Vikram Singh — RYGB on 28 May" },
    { icon: <Icon.Wallet        size={14} />, color: "#8E5A23", title: "Payment pending",      body: "Diya Shah — Rhinoplasty advance ₹50,000" },
    { icon: <Icon.Doc           size={14} />, color: "#1F4D44", title: "Upload reports",       body: "Aanya Mehta — TPA needs blood reports" },
    { icon: <Icon.Phone         size={14} />, color: "#B87A3A", title: "Confirmation call",    body: "3 patients tomorrow have not confirmed" },
  ];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {items.map((it, i) => (
        <div key={i} style={{ display: "flex", gap: 10, padding: 10, borderRadius: 10, background: "var(--bg-sunken)" }}>
          <div style={{
            width: 28, height: 28, borderRadius: 7,
            background: it.color + "20", color: it.color,
            display: "grid", placeItems: "center", flexShrink: 0,
          }}>{it.icon}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12.5, fontWeight: 500 }}>{it.title}</div>
            <div style={{ fontSize: 11.5, color: "var(--text-mute)" }}>{it.body}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function LeadSourceBars() {
  const rows = [
    { l: "Instagram",       v: 38, c: "#E1306C" },
    { l: "Google Search",   v: 24, c: "#4285F4" },
    { l: "Practo",          v: 12, c: "#5D32D7" },
    { l: "Doctor Referral", v: 9,  c: "#1F4D44" },
    { l: "YouTube",         v: 6,  c: "#CD201F" },
    { l: "Walk-in",         v: 4,  c: "#B87A3A" },
  ];
  const max = Math.max(...rows.map(r => r.v));
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
      {rows.map(r => (
        <div key={r.l}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 4 }}>
            <span style={{ color: "var(--text-mute)" }}>{r.l}</span>
            <span style={{ fontFamily: "var(--f-mono)" }}>{r.v}</span>
          </div>
          <div style={{ height: 6, background: "var(--bg-sunken)", borderRadius: 3 }}>
            <div style={{ height: "100%", width: `${(r.v / max) * 100}%`, background: r.c, borderRadius: 3 }} />
          </div>
        </div>
      ))}
    </div>
  );
}

// =====================================================================
// New Booking Modal — 3 steps (Patient → Slot → Payment) w/ WhatsApp preview
// =====================================================================
FD.BookingModal = function ({ open, onClose }) {
  const D = window.KAAYANTAR_DATA;
  const toast = useToast();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    name: "Riya Kapoor", age: "32", dob: "1993-08-12", sex: "F", phone: "+91 98250 11234",
    type: "new", doctor: "dr-ps", date: "2026-05-17", time: "",
    leadSource: "Instagram Ad", fee: 1500,
  });
  const [payMode, setPayMode] = useState("qr");
  const [sending, setSending] = useState(false);

  useEffect(() => { if (!open) { setStep(1); setSending(false); } }, [open]);
  const f = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const book = () => {
    setSending(true);
    setTimeout(() => {
      toast.push({
        title: "Booking confirmed", kind: "wa",
        body: `WhatsApp sent to ${form.name} & ${doctorById(form.doctor).name}`,
      });
      onClose();
    }, 1300);
  };

  return (
    <Modal open={open} onClose={onClose} width={1040}
      title={step === 1 ? "New appointment" : step === 2 ? "Pick a slot" : "Payment & confirmation"}
      subtitle="Patient → Doctor → Slot → Payment. WhatsApp confirmation auto-sends with location + Dr. profile link."
      footer={
        <>
          <Steps step={step} />
          <div style={{ display: "flex", gap: 8 }}>
            {step > 1 && <button className="btn" onClick={() => setStep(step - 1)}>Back</button>}
            {step < 3 && (
              <button className="btn primary"
                disabled={step === 2 && !form.time}
                onClick={() => setStep(step + 1)}>
                Continue <Icon.Right size={12} />
              </button>
            )}
            {step === 3 && (
              <button className="btn primary" onClick={book}>
                <Icon.Check size={14} /> Book & send WhatsApp
              </button>
            )}
          </div>
        </>
      }
    >
      {step === 1 && <Step1Patient f={f} form={form} />}
      {step === 2 && <Step2Slot    f={f} form={form} />}
      {step === 3 && <Step3Payment form={form} payMode={payMode} setPayMode={setPayMode} sending={sending} />}
    </Modal>
  );
};

function Steps({ step }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      {["Patient", "Slot", "Payment"].map((l, i) => (
        <React.Fragment key={l}>
          <div style={{
            display: "flex", alignItems: "center", gap: 6,
            color: i + 1 === step ? "var(--text)" : "var(--text-dim)",
            fontSize: 12, fontWeight: 500,
          }}>
            <div style={{
              width: 20, height: 20, borderRadius: "50%",
              background: i + 1 <= step ? "var(--brand)" : "var(--bg-sunken)",
              color: i + 1 <= step ? "var(--brand-ink)" : "var(--text-dim)",
              display: "grid", placeItems: "center",
              fontSize: 11, fontWeight: 600, fontFamily: "var(--f-mono)",
            }}>{i + 1}</div>
            {l}
          </div>
          {i < 2 && <div style={{ width: 16, height: 1, background: "var(--line-strong)" }} />}
        </React.Fragment>
      ))}
    </div>
  );
}

function Step1Patient({ f, form }) {
  const D = window.KAAYANTAR_DATA;
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 24 }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div className="seg">
          <button className={form.type === "new" ? "on" : ""}       onClick={() => f("type", "new")}>New OPD</button>
          <button className={form.type === "follow-up" ? "on" : ""} onClick={() => f("type", "follow-up")}>Follow-up</button>
        </div>

        {form.type === "follow-up" && (
          <div style={{
            padding: 12, background: "var(--emerald-50)",
            border: "1px solid var(--emerald-200)", borderRadius: 10,
            display: "flex", flexDirection: "column", gap: 8,
          }}>
            <div className="field">
              <label>Search existing patient</label>
              <div style={{ position: "relative" }}>
                <input className="input" placeholder="Phone, name or UHID" style={{ paddingLeft: 32 }} />
                <Icon.Search size={14} style={{ position: "absolute", left: 10, top: 11, color: "var(--text-mute)" }} />
              </div>
            </div>
            <div className="helper">
              Last 3 OPDs auto-attach to this booking — past prescriptions, photos, and doctor's notes appear inside today's consult.
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {D.patients.slice(0, 2).map(p => (
                <div key={p.id} style={{
                  display: "flex", alignItems: "center", gap: 8, padding: "6px 10px",
                  background: "var(--bg-elev)", borderRadius: 8,
                  border: "1px solid var(--line)", fontSize: 12.5,
                }}>
                  <Avatar name={p.name} size="sm" />
                  <span style={{ fontWeight: 500 }}>{p.name}</span>
                  <span style={{ color: "var(--text-mute)" }}>· {p.phone}</span>
                  <span style={{ marginLeft: "auto", color: "var(--text-mute)", fontSize: 11 }}>
                    {p.visit.count} past OPD{p.visit.count > 1 ? "s" : ""}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="field">
          <label>Full name <span className="req">*</span></label>
          <input className="input" value={form.name} onChange={(e) => f("name", e.target.value)} placeholder="e.g. Riya Kapoor" />
        </div>

        <div className="field-row">
          <div className="field">
            <label>Age</label>
            <input className="input" value={form.age} onChange={(e) => f("age", e.target.value)} placeholder="32" />
          </div>
          <div className="field">
            <label>DOB</label>
            <input className="input" type="date" value={form.dob} onChange={(e) => f("dob", e.target.value)} />
          </div>
          <div className="field" style={{ maxWidth: 110 }}>
            <label>Sex</label>
            <select className="select" value={form.sex} onChange={(e) => f("sex", e.target.value)}>
              <option>F</option><option>M</option><option>Other</option>
            </select>
          </div>
        </div>

        <div className="field">
          <label>Phone (WhatsApp) <span className="req">*</span></label>
          <input className="input" value={form.phone} onChange={(e) => f("phone", e.target.value)} placeholder="+91 98xxx xxxxx" />
        </div>

        <div className="field-row">
          <div className="field">
            <label>Consulting doctor</label>
            <select className="select" value={form.doctor} onChange={(e) => f("doctor", e.target.value)}>
              {D.doctors.map(d => <option key={d.id} value={d.id}>{d.name} — {d.spec}</option>)}
            </select>
          </div>
          <div className="field" style={{ maxWidth: 130 }}>
            <label>OPD fees</label>
            <input className="input" value={"₹" + form.fee} readOnly />
          </div>
        </div>

        <div className="field">
          <label>Lead source <span style={{ color: "var(--text-dim)", fontWeight: 400 }}>(auto-syncs to CRM)</span></label>
          <select className="select" value={form.leadSource} onChange={(e) => f("leadSource", e.target.value)}>
            {D.leadSources.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div style={{
        background: "var(--bg-sunken)", borderRadius: 14, padding: 16,
        display: "flex", flexDirection: "column", gap: 12,
      }}>
        <div style={{
          fontSize: 11, textTransform: "uppercase", letterSpacing: ".08em",
          color: "var(--text-mute)", fontWeight: 600,
        }}>Patient summary</div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Avatar name={form.name || "?"} size="lg" />
          <div>
            <div style={{ fontFamily: "var(--f-display)", fontSize: 22, fontWeight: 500 }}>
              {form.name || "—"}
            </div>
            <div style={{ fontSize: 12, color: "var(--text-mute)" }}>
              {form.age ? form.age + "y · " : ""}{form.sex}{form.phone ? " · " + form.phone : ""}
            </div>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 12 }}>
          <SumRow l="Visit"       v={form.type === "new" ? "New OPD" : "Follow-up"} />
          <SumRow l="Doctor"      v={doctorById(form.doctor).name} />
          <SumRow l="Fee"         v={inr(form.fee)} />
          <SumRow l="Lead source" v={form.leadSource} />
          <SumRow l="Clinic"      v="Kaayantar, Sindhu Bhavan Rd" />
        </div>
        <div style={{
          marginTop: "auto",
          background: "var(--bg-elev)", borderRadius: 10, padding: 10,
          fontSize: 11.5, color: "var(--text-mute)",
          display: "flex", gap: 8, alignItems: "flex-start",
        }}>
          <Icon.MessageCircle size={14} />
          Patient and doctor get a WhatsApp confirmation immediately, plus a 30-minute reminder containing clinic location and the doctor's profile link.
        </div>
      </div>
    </div>
  );
}

function SumRow({ l, v }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between" }}>
      <span style={{ color: "var(--text-mute)" }}>{l}</span>
      <span style={{ fontWeight: 500 }}>{v}</span>
    </div>
  );
}

function Step2Slot({ f, form }) {
  const D = window.KAAYANTAR_DATA;
  const doc = doctorById(form.doctor);
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
      <div>
        <div className="field-row" style={{ marginBottom: 14 }}>
          <div className="field">
            <label>Date</label>
            <input className="input" type="date" value={form.date} onChange={(e) => f("date", e.target.value)} />
          </div>
          <div className="field">
            <label>Doctor</label>
            <div className="input" style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ width: 8, height: 8, borderRadius: 4, background: doc.color }} />
              {doc.name}
            </div>
          </div>
        </div>
        <div style={{
          fontSize: 11, color: "var(--text-mute)", textTransform: "uppercase",
          letterSpacing: ".08em", fontWeight: 600, marginBottom: 8,
        }}>Available slots · 30 min each</div>
        <div className="slots">
          {D.slots.map(s => {
            const busy = D.busy.has(s);
            const sel = form.time === s;
            return (
              <button key={s}
                className={"slot" + (busy ? " busy" : "") + (sel ? " sel" : "")}
                onClick={() => !busy && f("time", s)}>{s}</button>
            );
          })}
        </div>
        <div style={{ display: "flex", gap: 14, marginTop: 14, fontSize: 11.5, color: "var(--text-mute)", alignItems: "center" }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
            <span className="slot" style={{ display: "inline-block", width: 14, height: 14, padding: 0 }} /> Free
          </span>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
            <span className="slot busy" style={{ display: "inline-block", width: 14, height: 14, padding: 0 }} /> Booked
          </span>
          <span style={{ marginLeft: "auto", display: "inline-flex", alignItems: "center", gap: 6 }}>
            <Icon.Sparkles size={12} /> Google Calendar synced — no overlap with OT
          </span>
        </div>
      </div>

      <div>
        <div style={{
          fontSize: 11, color: "var(--text-mute)", textTransform: "uppercase",
          letterSpacing: ".08em", fontWeight: 600, marginBottom: 8,
        }}>
          {doc.name}'s day · {new Date(form.date).toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "short" })}
        </div>
        <div style={{ background: "var(--bg-sunken)", borderRadius: 12, padding: 14, height: 340, overflow: "hidden" }}>
          <DayCalendar selectedTime={form.time} />
        </div>
      </div>
    </div>
  );
}

function DayCalendar({ selectedTime }) {
  const hours = []; for (let h = 10; h <= 18; h++) hours.push(h);
  const events = [
    { t: "10:00", dur: 30, l: "Pre-op planning — Rohit V.", c: "#B87A3A" },
    { t: "11:00", dur: 60, l: "OPD block — confirmed",       c: "#1F4D44" },
    { t: "12:30", dur: 30, l: "Imran S. — New",                c: "#3D6E63" },
    { t: "14:00", dur: 90, l: "OT — Rhinoplasty",              c: "#6B4218" },
    { t: "16:30", dur: 30, l: "Photoshoot review",             c: "#4A5552" },
  ];
  const rowH = 34;
  return (
    <div style={{ position: "relative", height: hours.length * rowH }}>
      {hours.map(h => (
        <div key={h} style={{
          display: "flex", gap: 8, borderTop: "1px dashed var(--line-strong)",
          height: rowH, alignItems: "flex-start",
        }}>
          <div style={{ width: 44, fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--text-mute)", paddingTop: 4 }}>
            {String(h).padStart(2, "0")}:00
          </div>
          <div style={{ flex: 1 }} />
        </div>
      ))}
      {events.map((e, i) => {
        const [h, m] = e.t.split(":").map(Number);
        const top = (h - 10) * rowH + (m / 60) * rowH;
        const height = (e.dur / 60) * rowH;
        return (
          <div key={i} style={{
            position: "absolute", left: 52, right: 0, top, height: height - 2,
            background: e.c, color: "#fff", borderRadius: 6, padding: "4px 8px",
            fontSize: 11, fontWeight: 500, display: "flex", alignItems: "center",
            boxShadow: "0 1px 3px rgba(0,0,0,.15)",
          }}>{e.t} · {e.l}</div>
        );
      })}
      {selectedTime && (() => {
        const [h, m] = selectedTime.split(":").map(Number);
        const top = (h - 10) * rowH + (m / 60) * rowH;
        return (
          <div style={{
            position: "absolute", left: 52, right: 0, top: top - 1, height: rowH / 2,
            border: "2px dashed #B87A3A",
            background: "color-mix(in srgb, #B87A3A 18%, transparent)",
            borderRadius: 6, display: "flex", alignItems: "center",
            padding: "0 8px", fontSize: 11, fontWeight: 600, color: "#6B4218",
          }}>★ {selectedTime} · New booking</div>
        );
      })()}
    </div>
  );
}

function Step3Payment({ form, payMode, setPayMode, sending }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 24 }}>
      <div>
        <div style={{
          fontSize: 11, color: "var(--text-mute)", textTransform: "uppercase",
          letterSpacing: ".08em", fontWeight: 600, marginBottom: 8,
        }}>OPD fees · {inr(form.fee)}</div>

        <div className="seg" style={{ marginBottom: 14, flexWrap: "wrap" }}>
          <button className={payMode === "qr"   ? "on" : ""} onClick={() => setPayMode("qr")}>  <Icon.QR     size={14} /> Share QR</button>
          <button className={payMode === "link" ? "on" : ""} onClick={() => setPayMode("link")}><Icon.Link   size={14} /> Payment link</button>
          <button className={payMode === "bank" ? "on" : ""} onClick={() => setPayMode("bank")}><Icon.Bank   size={14} /> Bank details</button>
          <button className={payMode === "cash" ? "on" : ""} onClick={() => setPayMode("cash")}><Icon.Wallet size={14} /> Cash / Card</button>
        </div>

        {payMode === "qr" && (
          <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
            <QRPlaceholder />
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "var(--f-display)", fontSize: 22, fontWeight: 500, marginBottom: 4 }}>UPI QR · Kaayantar LLP</div>
              <div style={{ fontSize: 12, color: "var(--text-mute)", marginBottom: 12, fontFamily: "var(--f-mono)" }}>
                kaayantar@hdfcbank
              </div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                <button className="btn sm primary"><Icon.MessageCircle size={12} /> Send via WhatsApp</button>
                <button className="btn sm"><Icon.Send size={12} /> Email QR</button>
                <button className="btn sm"><Icon.Doc size={12} /> Print</button>
              </div>
            </div>
          </div>
        )}
        {payMode === "link" && (
          <div className="field">
            <label>Generated payment link</label>
            <div style={{ display: "flex", gap: 6 }}>
              <input className="input" readOnly
                value="https://pay.kaayantar.com/r/3K9-Riya-1500"
                style={{ fontFamily: "var(--f-mono)", fontSize: 12 }} />
              <button className="btn">Copy</button>
            </div>
            <div className="helper">Razorpay / PhonePe checkout · auto-marks payment received when settled.</div>
            <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
              <button className="btn sm primary"><Icon.MessageCircle size={12} /> Send via WhatsApp</button>
              <button className="btn sm">SMS</button>
              <button className="btn sm">Email</button>
            </div>
          </div>
        )}
        {payMode === "bank" && (
          <div style={{ background: "var(--bg-sunken)", padding: 16, borderRadius: 10, fontFamily: "var(--f-mono)", fontSize: 12.5, lineHeight: 1.9 }}>
            <div>A/c name : KAAYANTAR LLP</div>
            <div>A/c no   : 50200 0123 4567 89</div>
            <div>IFSC     : HDFC0001234</div>
            <div>Branch   : Sindhu Bhavan Rd, Ahmedabad</div>
            <div>UPI      : kaayantar@hdfcbank</div>
            <div style={{ marginTop: 10, display: "flex", gap: 6 }}>
              <button className="btn sm primary"><Icon.MessageCircle size={12} /> Share on WhatsApp</button>
              <button className="btn sm">Copy all</button>
            </div>
          </div>
        )}
        {payMode === "cash" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <div className="field-row">
              <div className="field"><label>Mode</label>
                <select className="select"><option>Cash</option><option>Card — Pinelabs</option></select>
              </div>
              <div className="field"><label>Amount</label><input className="input" defaultValue="1500" /></div>
            </div>
            <div className="field"><label>Receipt number</label><input className="input" defaultValue="KAY-2026-05-318" /></div>
            <button className="btn primary"><Icon.Receipt size={12} /> Mark paid & print</button>
          </div>
        )}
      </div>

      <WhatsAppPreview form={form} sending={sending} />
    </div>
  );
}

function QRPlaceholder() {
  const cells = 21;
  const seed = "kaayantar-opd";
  const rects = [];
  for (let y = 0; y < cells; y++) {
    for (let x = 0; x < cells; x++) {
      const k = (x * 11 + y * 7 + seed.charCodeAt((x + y) % seed.length)) % 100;
      const inCornerArea =
        (x < 7 && y < 7) || (x > cells - 8 && y < 7) || (x < 7 && y > cells - 8);
      const cornerOuter =
        ((x === 0 || x === 6) && y < 7) || ((y === 0 || y === 6) && x < 7) ||
        ((x === cells - 1 || x === cells - 7) && y < 7) || ((y === 0 || y === 6) && x > cells - 8) ||
        ((x === 0 || x === 6) && y > cells - 8) || ((y === cells - 1 || y === cells - 7) && x < 7);
      const cornerInner =
        (x >= 2 && x <= 4 && y >= 2 && y <= 4) ||
        (x >= cells - 5 && x <= cells - 3 && y >= 2 && y <= 4) ||
        (x >= 2 && x <= 4 && y >= cells - 5 && y <= cells - 3);
      const on = inCornerArea ? (cornerOuter || cornerInner) : k > 48;
      if (on) rects.push(<rect key={x + "-" + y} x={x} y={y} width="1" height="1" fill="#0E1513" />);
    }
  }
  return (
    <div style={{
      width: 160, height: 160, background: "#fff", borderRadius: 10,
      padding: 8, border: "1px solid var(--line)", position: "relative",
    }}>
      <svg width="100%" height="100%" viewBox={`0 0 ${cells} ${cells}`}>{rects}</svg>
      <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", pointerEvents: "none" }}>
        <div style={{
          width: 30, height: 30, borderRadius: 7,
          background: "var(--bronze-500)", color: "#fff",
          display: "grid", placeItems: "center",
          fontFamily: "var(--f-display)", fontSize: 18, fontWeight: 500,
          border: "2px solid #fff",
        }}>K</div>
      </div>
    </div>
  );
}

function WhatsAppPreview({ form, sending }) {
  const doc = doctorById(form.doctor);
  const dateLabel = new Date(form.date).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" });
  return (
    <div className="wa-phone">
      <div className="notch" />
      <div className="wa-status">
        <span>9:41</span>
        <span>●●● 5G ▮</span>
      </div>
      <div className="wa-head">
        <div className="av">K</div>
        <div style={{ flex: 1 }}>
          <b>Kaayantar Clinic</b><br />
          <small>online · auto-reply enabled</small>
        </div>
        <Icon.Phone size={16} />
      </div>
      <div className="wa-body">
        <div className="wa-msg">
          <b>Namaste {form.name || "—"} 🙏</b>{"\n"}
          Your OPD appointment is confirmed.
          <div className="preview">
            👨‍⚕️ <b>{doc.name}</b><br />
            📅 {dateLabel} · {form.time || "—:—"}<br />
            🏥 Kaayantar, Sindhu Bhavan Rd, Ahmedabad<br />
            💰 Consultation: {inr(form.fee)}
          </div>
          📍 <u>Open in Maps</u>{"\n"}🔗 <u>About {doc.name.split(" ")[1] || "doctor"}</u>
          <div className="t">9:41 AM <span className="tick">✓✓</span></div>
        </div>
        {sending && (
          <div className="wa-msg" style={{ opacity: .65 }}>
            <span className="pulse">Sending reminder template…</span>
          </div>
        )}
        <div className="wa-msg" style={{ background: "#FFF9D6" }}>
          <b>⏰ Reminder · 30 min before</b>{"\n"}
          You have an appointment in 30 min with {doc.name}.{"\n"}
          Please arrive 10 min early with previous reports.
          <div className="t">scheduled <span className="tick">○</span></div>
        </div>
      </div>
    </div>
  );
}

// =====================================================================
// Patient List
// =====================================================================
FD.PatientList = function ({ go, openBooking }) {
  const D = window.KAAYANTAR_DATA;
  const [q, setQ] = useState("");
  const filtered = D.patients.filter(p =>
    !q || p.name.toLowerCase().includes(q.toLowerCase()) || p.phone.includes(q));
  return (
    <div>
      <div className="canvas-head">
        <div>
          <h1>Patients</h1>
          <p>{D.patients.length} active records · {D.patients.filter(p => p.surgery.suggested).length} with surgery planned</p>
        </div>
        <div className="actions">
          <button className="btn"><Icon.Upload size={14} /> Import</button>
          <button className="btn primary" onClick={openBooking}>
            <Icon.Plus size={14} /> New patient
          </button>
        </div>
      </div>

      <div className="card" style={{ padding: 0 }}>
        <div style={{ padding: 14, borderBottom: "1px solid var(--line)", display: "flex", gap: 10, alignItems: "center" }}>
          <div className="topbar-search-shell" style={{
            flex: 1, display: "flex", alignItems: "center", gap: 8,
            height: 36, padding: "0 12px", background: "var(--bg-sunken)", borderRadius: 8,
          }}>
            <Icon.Search size={14} />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name or phone"
              style={{ border: 0, background: "transparent", outline: "none", flex: 1, fontSize: 13, color: "var(--text)" }} />
          </div>
          <div className="seg">
            <button className="on">All</button>
            <button>New</button>
            <button>Follow-up</button>
            <button>Surgery planned</button>
            <button>Post-op</button>
          </div>
        </div>
        <table className="tbl">
          <thead>
            <tr>
              <th>Patient</th><th>Phone</th><th>Lead source</th><th>Last OPD</th><th>Status</th><th>Surgery</th><th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(p => (
              <tr key={p.id}>
                <td>
                  <div className="pt-cell">
                    <Avatar name={p.name} size="sm" />
                    <div>
                      <div className="name">{p.name}</div>
                      <div className="meta">{p.age}y · {p.sex} · {p.city}</div>
                    </div>
                  </div>
                </td>
                <td style={{ fontFamily: "var(--f-mono)" }}>{p.phone}</td>
                <td><Badge>{p.lead.source}</Badge></td>
                <td style={{ fontFamily: "var(--f-mono)", color: "var(--text-mute)" }}>
                  {p.history[0]?.date || "—"}
                </td>
                <td><FdStatusBadge status={p.status} /></td>
                <td>{p.surgery.suggested
                  ? <span style={{ fontSize: 12.5 }}>{p.surgery.procedure}</span>
                  : <span style={{ color: "var(--text-dim)" }}>—</span>}</td>
                <td style={{ textAlign: "right" }}>
                  <button className="btn sm ghost" onClick={() => go({ view: "patient", id: p.id })}>
                    Open <Icon.Right size={12} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

Object.assign(window, { FD });
