// crm.jsx — Right-rail CRM strip (lead source, funnel, lead→OPD→IPD timings)

function CRMStrip({ patientId, role }) {
  const D = window.KAAYANTAR_DATA;
  const p = patientId ? D.patients.find(x => x.id === patientId) : null;

  return (
    <>
      <div style={{
        padding: "16px 18px 12px",
        borderBottom: "1px solid var(--line)",
        background: "linear-gradient(180deg, var(--emerald-50), var(--bg-elev))",
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
          <div style={{ fontSize: 10.5, color: "var(--text-mute)", textTransform: "uppercase",
                         letterSpacing: ".1em", fontWeight: 600 }}>CRM · live</div>
          <Badge kind="ok" dot>Synced</Badge>
        </div>
        <div style={{ fontFamily: "var(--f-display)", fontSize: 18, fontWeight: 500, color: "var(--emerald-700)" }}>
          {p ? p.name : "Funnel — this month"}
        </div>
        <div style={{ fontSize: 11, color: "var(--text-mute)" }}>
          {p ? `${p.lead.source} · ${p.tags[0] || "Patient"}` : "412 leads · 64 procedures completed"}
        </div>
      </div>

      {p ? <PatientCRM p={p} /> : <ClinicCRM D={D} />}

      <div style={{ padding: 14, marginTop: "auto", borderTop: "1px solid var(--line)", fontSize: 11, color: "var(--text-mute)", display: "flex", gap: 8, alignItems: "flex-start" }}>
        <Icon.Sparkles size={12} />
        <span>This panel is a read-only slice of the upcoming CRM. Lead status flips here when OPD/IPD events happen on the left.</span>
      </div>
    </>
  );
}

function PatientCRM({ p }) {
  const D = window.KAAYANTAR_DATA;
  const created = new Date(p.lead.createdAt);
  const firstOpd = new Date(p.lead.firstOpdAt);
  const surgery = p.surgery.suggested && p.surgery.date ? new Date(p.surgery.date + "T" + p.surgery.time) : null;
  const leadToOpd = Math.round((firstOpd - created) / 86400000);
  const opdToSurg = surgery ? Math.round((surgery - firstOpd) / 86400000) : null;

  const steps = [
    { dot: "done",    label: "Lead created",       sub: p.lead.source,                                            time: created.toLocaleDateString("en-IN", { day: "numeric", month: "short" }) },
    { dot: "done",    label: "Qualified",           sub: "by Front Desk · " + (p.tags[0] || "—"),                  time: "+1d" },
    { dot: "done",    label: "OPD booked",          sub: doctorById(p.visit.doctor).name,                          time: "+" + Math.max(1, leadToOpd - 2) + "d" },
    { dot: "done",    label: "OPD completed",       sub: leadToOpd + " days from lead",                            time: firstOpd.toLocaleDateString("en-IN", { day: "numeric", month: "short" }) },
    p.surgery.suggested ? { dot: "done",    label: "Surgery suggested", sub: p.surgery.procedure,                          time: "+0d" }
                         : { dot: "skipped", label: "Surgery suggested", sub: "Not advised",                                   time: "—" },
    p.surgery.done       ? { dot: "done",    label: "Surgery done",      sub: p.surgery.procedure + " · " + D.hospitals.find(h => h.id === p.surgery.hospital)?.name?.split(",")[0], time: new Date(p.surgery.date).toLocaleDateString("en-IN", { day: "numeric", month: "short" }) }
    : p.surgery.suggested ? { dot: "pending", label: "Surgery scheduled", sub: new Date(p.surgery.date).toLocaleDateString("en-IN", { day: "numeric", month: "short" }) + " · " + p.surgery.time, time: "T-" + Math.max(0, Math.round((surgery - new Date(2026, 4, 19)) / 86400000)) + "d" }
                          : { dot: "skipped", label: "Surgery", sub: "—", time: "—" },
  ];

  return (
    <>
      <div className="crm-section">
        <h4>Funnel position</h4>
        <div className="lead-funnel">
          {steps.map((s, i) => (
            <div className="funnel-step" key={i}>
              <span className={"dot " + (s.dot === "pending" ? "pending" : s.dot === "skipped" ? "skipped" : "")} />
              <div className="stp-meta">
                <b>{s.label}</b>
                <span>{s.sub}</span>
              </div>
              <span className="stp-time">{s.time}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="crm-section">
        <h4>Cycle times</h4>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <MiniStat l="Lead → OPD"     v={leadToOpd}    u="days" trend={leadToOpd <= 5 ? "good" : "bad"} />
          <MiniStat l="OPD → Surgery"  v={opdToSurg ?? "—"} u={opdToSurg ? "days" : ""} trend={opdToSurg && opdToSurg <= 25 ? "good" : "neutral"} />
          <MiniStat l="Touchpoints"    v={p.history.length + 2} u="" />
          <MiniStat l="WhatsApp opens" v={p.surgery.suggested ? 14 : 4}  u="" />
        </div>
      </div>

      <div className="crm-section">
        <h4>Touchpoints</h4>
        <div style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 11.5 }}>
          <TouchRow icon={<Icon.MessageCircle size={11} />} l="Booking confirmed"   t="WhatsApp · auto" when="14 May" />
          <TouchRow icon={<Icon.Phone size={11} />}         l="Confirmation call"   t="Asmita · 2 min"   when="15 May" />
          <TouchRow icon={<Icon.MessageCircle size={11} />} l="Pre-op pack shared"  t="WhatsApp · ✓✓"    when="16 May" />
          {p.surgery.suggested && <TouchRow icon={<Icon.Receipt size={11} />} l="Estimate sent" t={inr(p.surgery.packageInr)} when="16 May" />}
        </div>
      </div>

      <div className="crm-section">
        <h4>Next CRM action</h4>
        <div style={{
          padding: 10, borderRadius: 8,
          background: "var(--bronze-100)", color: "var(--bronze-700)",
          fontSize: 12, display: "flex", alignItems: "flex-start", gap: 8,
        }}>
          <Icon.Bell size={12} />
          <div>
            <b style={{ display: "block", fontWeight: 600 }}>
              {p.surgery.suggested && !p.surgery.done ? "Pre-op nurture · D-2 call" : p.surgery.done ? "Post-op satisfaction call · D+30" : "Re-engage warm lead"}
            </b>
            <span>Owner: Front Desk · auto-assigned</span>
          </div>
        </div>
      </div>
    </>
  );
}

function ClinicCRM({ D }) {
  const total = D.funnelDistribution[0].value;
  return (
    <>
      <div className="crm-section">
        <h4>Funnel</h4>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {D.funnelDistribution.map((f, i) => {
            const pct = (f.value / total) * 100;
            return (
              <div key={f.label}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11.5, marginBottom: 3 }}>
                  <span>{f.label}</span>
                  <span style={{ fontFamily: "var(--f-mono)" }}>
                    {f.value} <span style={{ color: "var(--text-dim)" }}>· {pct.toFixed(0)}%</span>
                  </span>
                </div>
                <div style={{ height: 8, background: "var(--bg-sunken)", borderRadius: 4 }}>
                  <div style={{
                    height: "100%", width: `${pct}%`,
                    background: `hsl(${165 - i * 8} ${40 - i * 4}% ${30 + i * 6}%)`,
                    borderRadius: 4,
                  }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="crm-section">
        <h4>Cycle times</h4>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <MiniStat l="Lead → OPD"  v={D.crmStats.leadToOpd.days}  u="days" trend="good" delta={D.crmStats.leadToOpd.delta} />
          <MiniStat l="OPD → IPD"   v={D.crmStats.opdToIpd.days}   u="days" trend="neutral" delta={D.crmStats.opdToIpd.delta} />
          <MiniStat l="Conversion"  v={(D.crmStats.leadConv * 100).toFixed(1)} u="%" trend="good" />
          <MiniStat l="Drop-off"    v="38" u="%" trend="bad" />
        </div>
      </div>

      <div className="crm-section">
        <h4>Lead sources</h4>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {[
            { l: "Instagram",   v: 156, c: "#E1306C" },
            { l: "Google",      v: 98,  c: "#4285F4" },
            { l: "Practo",      v: 52,  c: "#5D32D7" },
            { l: "Referral",    v: 42,  c: "#1F4D44" },
            { l: "YouTube",     v: 38,  c: "#CD201F" },
            { l: "Walk-in",     v: 26,  c: "#B87A3A" },
          ].map(r => {
            const pct = (r.v / 156) * 100;
            return (
              <div key={r.l}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11.5, marginBottom: 3 }}>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                    <span style={{ width: 8, height: 8, borderRadius: 4, background: r.c }} />{r.l}
                  </span>
                  <span style={{ fontFamily: "var(--f-mono)" }}>{r.v}</span>
                </div>
                <div style={{ height: 4, background: "var(--bg-sunken)", borderRadius: 2 }}>
                  <div style={{ height: "100%", width: `${pct}%`, background: r.c, borderRadius: 2 }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

function MiniStat({ l, v, u, trend, delta }) {
  return (
    <div style={{
      padding: 10, borderRadius: 8,
      background: "var(--bg-sunken)",
    }}>
      <div style={{ fontSize: 10, color: "var(--text-mute)", textTransform: "uppercase",
                     letterSpacing: ".06em", fontWeight: 600 }}>{l}</div>
      <div style={{ fontFamily: "var(--f-display)", fontSize: 22, fontWeight: 500, lineHeight: 1.1, marginTop: 2 }}>
        {v}{u ? <span style={{ fontSize: 11, color: "var(--text-mute)", fontFamily: "var(--f-sans)", marginLeft: 3, fontWeight: 500 }}>{u}</span> : null}
      </div>
      {delta != null ? (
        <div style={{ fontSize: 10.5, color: delta < 0 ? "var(--ok-fg)" : "var(--err-fg)", fontFamily: "var(--f-mono)" }}>
          {delta < 0 ? "↓" : "↑"} {Math.abs(delta)} vs last mo
        </div>
      ) : trend && (
        <div style={{ fontSize: 10.5, color: trend === "good" ? "var(--ok-fg)" : trend === "bad" ? "var(--err-fg)" : "var(--text-mute)", fontFamily: "var(--f-mono)" }}>
          {trend === "good" ? "↓ healthy" : trend === "bad" ? "↑ slow" : "—"}
        </div>
      )}
    </div>
  );
}

function TouchRow({ icon, l, t, when }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 0", borderBottom: "1px dashed var(--line)" }}>
      <span style={{
        width: 20, height: 20, borderRadius: 5,
        background: "var(--emerald-50)", color: "var(--emerald-700)",
        display: "grid", placeItems: "center", flexShrink: 0,
      }}>{icon}</span>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 500, fontSize: 11.5 }}>{l}</div>
        <div style={{ fontSize: 10.5, color: "var(--text-mute)" }}>{t}</div>
      </div>
      <div style={{ fontSize: 10.5, color: "var(--text-mute)", fontFamily: "var(--f-mono)" }}>{when}</div>
    </div>
  );
}

Object.assign(window, { CRMStrip });
